# ShortUploaderUI (C# / WPF) — echte Windows-App + Self-Contained EXE

## Ziel
- Echte Desktop-UI (WPF)
- Upload-Queue, Logs, Retry/Backoff, Scheduling
- Upload zu YouTube (Google API) + TikTok (TikTok Content Posting API — Direct Post)
- Nach Erfolg: Move nach `uploaded/`, sonst nach `failed/`

## Warum das „ohne Python“ funktioniert
Die Release-EXE wird mit `--self-contained` gebaut: die .NET Runtime wird mit in die App gepackt.
Auf dem Ziel-PC muss dann kein Python und kein .NET installiert sein.

## Aber: Wie kommt die EXE zustande?
Jemand muss sie einmal bauen. Zwei Wege:

### A) Lokal bauen (einmalig)
1. Installiere **.NET 8 SDK** (nur fürs Bauen)
2. Doppelklick auf `build_release.bat`
3. Die fertige EXE liegt in:
   `ShortUploaderUI\bin\Release\net8.0-windows\win-x64\publish\ShortUploaderUI.exe`

### B) Ohne lokale Installation: GitHub Actions
- Repo hochladen
- Workflow `Build Windows EXE` starten
- Artifact herunterladen → enthält fertige EXE + benötigte Dateien

## Setup für Upload (immer nötig)
- YouTube: `youtube_client_secret.json` ins publish-Verzeichnis legen
- TikTok: Access Token in der App im Tab „Plattformen“ eintragen

## Sicherheit
- TikTok Token wird lokal in `app_settings.json` gespeichert.
  Wenn du möchtest, kann ich das auf Windows Credential Manager umstellen.

## Hinweise
- TikTok/YouTube benötigen offizielle API-Rechte/Scopes.
- Diese App nutzt offizielle Schnittstellen und umgeht keine Schutzmechanismen.
