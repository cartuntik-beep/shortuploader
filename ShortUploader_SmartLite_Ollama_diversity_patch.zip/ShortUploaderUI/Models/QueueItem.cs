namespace ShortUploaderUI.Models;

public class QueueItem
{
    public string FullPath { get; set; } = "";
    public string FileName { get; set; } = "";
    // Smart Lite (local AI suggestions via Ollama)
    public string SuggestedTitle { get; set; } = "";
    public string SuggestedHashtags { get; set; } = ""; // space-separated
    public string SuggestedCaption { get; set; } = "";
    public string Status { get; set; } = "READY";
    public string YouTubeResult { get; set; } = "";
    public string TikTokResult { get; set; } = "";
    public string PublishAtLocal { get; set; } = "";
}
