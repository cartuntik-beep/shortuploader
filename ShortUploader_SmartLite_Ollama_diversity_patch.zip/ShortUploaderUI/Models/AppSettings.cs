namespace ShortUploaderUI.Models;

public class AppSettings
{
    public string? VideoFolder { get; set; } = "";
    public string[] FileExtensions { get; set; } = new[] { ".mp4", ".mov", ".webm" };

    // workflow
    public string MoveWhen { get; set; } = "both_succeeded"; // both_succeeded or any_succeeded

    // retry
    public int RetryMaxAttempts { get; set; } = 3;
    public int RetryBaseBackoffSeconds { get; set; } = 10;
    public int RetryMaxBackoffSeconds { get; set; } = 300;

    // scheduling (batch wait)
    public bool SchedulingEnabled { get; set; } = false;
    public string SchedulingStartAtLocal { get; set; } = ""; // "YYYY-MM-DD HH:MM"
    public int SchedulingIntervalMinutes { get; set; } = 60;


// Planning (publish calendar)
public bool PlanningEnabled { get; set; } = false;
    public bool UsePlatformScheduling { get; set; } = false; // upload now, platforms handle publish (YouTube true scheduling; TikTok draft/inbox workaround)
public string PlanningStartDate { get; set; } = ""; // "YYYY-MM-DD"
public int PlanningDays { get; set; } = 7; // horizon
public int PlanningVideosPerDay { get; set; } = 2;
public string PlanningTimesCsv { get; set; } = "10:00,18:00"; // local times
public string PlanningTimezoneId { get; set; } = ""; // optional TZ id; empty = local

    // YouTube
    public bool YouTubeEnabled { get; set; } = true;
    public string YouTubeClientSecretsFile { get; set; } = "youtube_client_secret.json";
    public string YouTubeTokenFile { get; set; } = "youtube_token.json";
    public string YouTubePrivacyStatus { get; set; } = "public";
    public string YouTubeCategoryId { get; set; } = "22";
    public string YouTubeTitleTemplate { get; set; } = "{stem} #Shorts";
    public string YouTubeDescriptionTemplate { get; set; } = "";
    public string[] YouTubeTags { get; set; } = new[] { "Shorts" };
    // TikTok
    public bool TikTokEnabled { get; set; } = true;

    // TikTok OAuth (Login Kit Desktop)
    public string TikTokClientKey { get; set; } = "";
    public string TikTokClientSecret { get; set; } = "";
    public string TikTokScopesCsv { get; set; } = "user.info.basic,video.publish";

    // Redirect URI parts (Desktop loopback)
    public string TikTokRedirectHost { get; set; } = "127.0.0.1";
    public int TikTokRedirectPort { get; set; } = 0; // 0 = random free port
    public string TikTokRedirectPath { get; set; } = "/callback/";

    // Posting options
    public string TikTokPrivacyLevel { get; set; } = "PUBLIC_TO_EVERYONE";
    public bool TikTokIsAigc { get; set; } = false;
    public string TikTokCaptionTemplate { get; set; } = "{stem}";
    public bool TikTokDisableComment { get; set; } = false;
    public bool TikTokDisableDuet { get; set; } = false;
    public bool TikTokDisableStitch { get; set; } = false;
    public int TikTokCoverTimestampMs { get; set; } = 1000;

    // Commercial content disclosure (UX guideline)
    public bool TikTokCommercialToggle { get; set; } = false;
    public bool TikTokCommercialYourBrand { get; set; } = false;
    public bool TikTokCommercialBrandedContent { get; set; } = false;

    // Smart Lite (Local AI via Ollama)
    public bool SmartLiteEnabled { get; set; } = false;
    public string SmartLiteOllamaBaseUrl { get; set; } = "http://localhost:11434";
    public string SmartLiteModel { get; set; } = "llama3.2-vision";
    public int SmartLiteFramesPerVideo { get; set; } = 8;
    public int SmartLiteMaxHashtags { get; set; } = 12;
    public string SmartLiteLanguage { get; set; } = "de"; // de|en|mixed
    public string SmartLiteStyle { get; set; } = "clean"; // clean|hype|cinematic|...
    public string SmartLiteFfmpegPath { get; set; } = ""; // optional absolute or relative path to ffmpeg.exe
    public string SmartLiteFfprobePath { get; set; } = ""; // optional absolute or relative path to ffprobe.exe

    // How to apply suggestions
    public bool SmartLiteApplyYouTubeTitle { get; set; } = true;
    public bool SmartLiteApplyYouTubeTags { get; set; } = true;
    public bool SmartLiteApplyTikTokCaption { get; set; } = true;

}
