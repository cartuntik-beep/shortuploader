using Microsoft.Win32;
using ShortUploaderUI.Models;
using ShortUploaderUI.Services;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Net.Http;
using Forms = System.Windows.Forms;

namespace ShortUploaderUI;

public partial class MainWindow : Window, INotifyPropertyChanged
{
    private readonly SettingsStore _settingsStore;
    private readonly UploaderOrchestrator _orchestrator;
    private readonly OllamaSmartLiteService _smartLite;
    // Ollama responses can be slow on CPU-only systems, especially with vision models.
    // Default HttpClient.Timeout is 100s which is often too low; use a more forgiving timeout.
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromMinutes(10) };

    public AppSettings Settings { get; private set; }

    private string _videoFolder = "";
    public string VideoFolder
    {
        get => _videoFolder;
        set { _videoFolder = value; OnPropertyChanged(); }
    }

    public string TikTokTokenStatus { get => _tikTokTokenStatus; set { _tikTokTokenStatus = value; OnPropertyChanged(); } }
    private string _tikTokTokenStatus = "(nicht eingeloggt)";

    public ObservableCollection<QueueItem> Queue { get; } = new();

    private string _statusText = "Bereit.";
    public string StatusText
    {
        get => _statusText;
        set { _statusText = value; OnPropertyChanged(); }
    }

    private string _logText = "";
    public string LogText
    {
        get => _logText;
        set { _logText = value; OnPropertyChanged(); }
    }

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;

        _settingsStore = new SettingsStore("app_settings.json");
        Settings = _settingsStore.LoadOrCreateDefault();
        VideoFolder = Settings.VideoFolder ?? "";

        // Populate sensitive UI fields after settings are loaded.
        TikTokClientSecretBox.Password = Settings.TikTokClientSecret ?? "";
        RefreshTikTokTokenStatus();

        // Smart Lite (Ollama)
        var appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ShortUploader");
        var logDir = Path.Combine(appData, "logs");
        var jsonLogger = new JsonlLogger(logDir);
        _smartLite = new OllamaSmartLiteService(_http, jsonLogger);


        _orchestrator = new UploaderOrchestrator(
            settingsProvider: () => Settings,
            onStatus: AppendStatus,
            onQueueUpdate: UpdateQueueRow
        );

        AppendStatus("App geladen.");
    }

    private async void SmartLiteGenerateAll_Click(object sender, RoutedEventArgs e)
    {
        if (!Settings.SmartLiteEnabled)
        {
            System.Windows.MessageBox.Show("Smart Lite ist in den Einstellungen deaktiviert. Bitte unter Plattformen → Smart Lite aktivieren.", "Hinweis", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        if (Queue.Count == 0)
        {
            System.Windows.MessageBox.Show("Queue ist leer. Erst scannen und Videos laden.", "Hinweis", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }

        AppendStatus("Smart Lite: Generiere Vorschläge (Ollama)…");

        // Run sequentially to keep CPU/GPU + disk usage stable
        // Also keep a rolling list of generated titles to enforce variety.
        var generatedTitles = new List<string>();
        var rng = new Random();

        for (int i = 0; i < Queue.Count; i++)
        {
            var item = Queue[i];
            try
            {
                AppendStatus($"Smart Lite: {item.FileName}…");
                // Try a few times to avoid repetitive titles (e.g. "midnight ride" across many night clips).
                OllamaSmartLiteService.SmartLiteResult? res = null;
                var attemptAvoid = new List<string>(generatedTitles);
                for (int attempt = 1; attempt <= 3; attempt++)
                {
                    var preset = PickVariationPreset(rng, attempt);
                    var candidate = await _smartLite.GenerateAsync(Settings, item.FullPath, CancellationToken.None,
                        variationPreset: preset,
                        avoidTitles: attemptAvoid);

                    // If the title is too close to previous ones, extend avoid list and retry.
                    if (IsTitleTooSimilar(candidate.Title, generatedTitles))
                    {
                        AppendStatus($"Smart Lite Hinweis: Titel zu ähnlich → erneuter Versuch {attempt}/3");
                        attemptAvoid.Add(candidate.Title);
                        continue;
                    }

                    res = candidate;
                    break;
                }

                res ??= await _smartLite.GenerateAsync(Settings, item.FullPath, CancellationToken.None,
                    variationPreset: "medium",
                    avoidTitles: attemptAvoid);

                item.SuggestedTitle = res.Title;
                item.SuggestedCaption = res.Caption;
                item.SuggestedHashtags = string.Join(" ", res.Hashtags);
                Queue[i] = item; // refresh row

                if (!string.IsNullOrWhiteSpace(res.Title))
                {
                    generatedTitles.Add(res.Title.Trim());
                    // keep memory bounded
                    if (generatedTitles.Count > 50)
                        generatedTitles.RemoveAt(0);
                }
            }
            catch (Exception ex)
            {
                AppendStatus($"Smart Lite Fehler ({item.FileName}): {ex.Message}");
            }
        }

        AppendStatus("Smart Lite: Fertig.");
    }

    private static string PickVariationPreset(Random rng, int attempt)
    {
        // Later attempts get stronger diversity presets.
        var presets = attempt switch
        {
            1 => new[] { "very_short", "short", "medium", "action" },
            2 => new[] { "hook", "cinematic", "medium", "action" },
            _ => new[] { "cinematic", "hook", "medium" }
        };
        return presets[rng.Next(presets.Length)];
    }

    private static bool IsTitleTooSimilar(string candidate, IReadOnlyList<string> previous)
    {
        if (string.IsNullOrWhiteSpace(candidate) || previous.Count == 0) return false;

        var candTokens = Tokenize(candidate);
        if (candTokens.Count == 0) return false;

        foreach (var prev in previous.TakeLast(20))
        {
            if (string.IsNullOrWhiteSpace(prev)) continue;
            var prevTokens = Tokenize(prev);
            if (prevTokens.Count == 0) continue;

            // Exact match
            if (string.Equals(Normalize(candidate), Normalize(prev), StringComparison.OrdinalIgnoreCase))
                return true;

            // Jaccard similarity on tokens
            var inter = candTokens.Intersect(prevTokens).Count();
            var union = candTokens.Union(prevTokens).Count();
            var jaccard = union == 0 ? 0.0 : (double)inter / union;

            // If very short, be stricter.
            var shortTitle = candTokens.Count <= 3 || prevTokens.Count <= 3;
            var threshold = shortTitle ? 0.45 : 0.60;
            if (jaccard >= threshold)
                return true;

            // Same first two tokens -> too similar
            if (candTokens.Count >= 2 && prevTokens.Count >= 2)
            {
                if (candTokens[0] == prevTokens[0] && candTokens[1] == prevTokens[1])
                    return true;
            }
        }

        return false;
    }

    private static string Normalize(string s)
        => Regex.Replace(s.ToLowerInvariant(), @"[^\p{L}\p{N}]+", " ").Trim();

    private static List<string> Tokenize(string s)
    {
        var norm = Normalize(s);
        var raw = norm.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        // lightweight stopword removal to reduce false similarity
        var stop = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "the","a","an","and","or","to","of","in","on","at","for","with","from",
            "ein","eine","und","oder","zu","von","im","in","am","auf","für","mit"
        };
        return raw.Where(t => t.Length >= 3 && !stop.Contains(t)).ToList();
    }

    private void SmartLiteClear_Click(object sender, RoutedEventArgs e)
    {
        for (int i = 0; i < Queue.Count; i++)
        {
            var item = Queue[i];
            item.SuggestedTitle = "";
            item.SuggestedCaption = "";
            item.SuggestedHashtags = "";
            Queue[i] = item;
        }
        AppendStatus("Smart Lite Vorschläge geleert.");
    }

    private void AppendStatus(string message)
    {
        Dispatcher.Invoke(() =>
        {
            StatusText = message;
            var ts = DateTime.Now.ToString("HH:mm:ss");
            LogText += $"[{ts}] {message}\n";
        });
    }

    private void UpdateQueueRow(int index, QueueItem updated)
    {
        Dispatcher.Invoke(() =>
        {
            if (index >= 0 && index < Queue.Count)
            {
                Queue[index] = updated;
            }
        });
    }

    private void PickFolder_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Forms.FolderBrowserDialog();
        dlg.Description = "Ordner mit Videos auswählen";
        dlg.UseDescriptionForTitle = true;

        var res = dlg.ShowDialog();
        if (res == Forms.DialogResult.OK && !string.IsNullOrWhiteSpace(dlg.SelectedPath))
        {
            VideoFolder = dlg.SelectedPath;
            Settings.VideoFolder = dlg.SelectedPath;
            AppendStatus("Ordner gewählt.");
        }
    }

    private void Scan_Click(object sender, RoutedEventArgs e)
    {
        Queue.Clear();

        if (string.IsNullOrWhiteSpace(VideoFolder) || !Directory.Exists(VideoFolder))
        {
            System.Windows.MessageBox.Show("Bitte einen gültigen Video-Ordner auswählen.", "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var videos = FileScanner.ListVideos(VideoFolder, Settings.FileExtensions);
        foreach (var p in videos)
        {
            Queue.Add(new QueueItem
            {
                FullPath = p,
                FileName = Path.GetFileName(p),
                Status = "READY",
                YouTubeResult = "",
                TikTokResult = ""
            });
        }

        ApplyPlanningToQueue();

        AppendStatus($"{Queue.Count} Video(s) in die Queue geladen.");
    }

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        if (Queue.Count == 0)
        {
            Scan_Click(sender, e);
            if (Queue.Count == 0) return;
        }

        try
        {
            SaveSettingsInternal();
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show(ex.Message, "Einstellungen ungültig", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }


        // TikTok UX guideline: require explicit user consent immediately before posting.
        if (Settings.TikTokEnabled)
        {
            var isCommercial = Settings.TikTokCommercialToggle;
            var yourBrand = Settings.TikTokCommercialYourBrand;
            var branded = Settings.TikTokCommercialBrandedContent;

            // Declaration text per guideline
            string declaration;
            if (isCommercial && branded)
                declaration = "By posting, you agree to TikTok's Branded Content Policy and Music Usage Confirmation.";
            else
                declaration = "By posting, you agree to TikTok's Music Usage Confirmation.";

            var privacyText = Settings.TikTokPrivacyLevel ?? "";
            var interactionsText =
                $"Comment: {(!Settings.TikTokDisableComment ? "ON" : "OFF")}, " +
                $"Duet: {(!Settings.TikTokDisableDuet ? "ON" : "OFF")}, " +
                $"Stitch: {(!Settings.TikTokDisableStitch ? "ON" : "OFF")}";

            var commercialText = isCommercial
                ? $"Disclosure ON — Your brand: {(yourBrand ? "YES" : "NO")}; Branded content: {(branded ? "YES" : "NO")}."
                : "Disclosure OFF";

            var videoCountText = $"{Queue.Count} video(s)";

            var dlg = new TikTokConsentWindow(declaration, privacyText, interactionsText, commercialText, videoCountText)
            {
                Owner = this
            };

            var ok = dlg.ShowDialog();
            if (ok != true)
            {
                AppendStatus("Upload abgebrochen: TikTok Consent nicht erteilt.");
                return;
            }
        }


// Ensure planned slots are assigned before starting.
if (Settings.PlanningEnabled || Settings.UsePlatformScheduling)
{
    ApplyPlanningToQueue();

    if (Settings.UsePlatformScheduling)
    {
        var missing = Queue.Where(q => string.IsNullOrWhiteSpace(q.PublishAtLocal)).Select(q => q.FileName).ToList();
        if (missing.Count > 0)
        {
            var msg = "Plattform-Planung ist aktiv, aber für folgende Dateien ist keine geplante Zeit gesetzt:\n"
                      + string.Join("\n", missing.Take(10))
                      + (missing.Count > 10 ? "\n…" : "")
                      + "\n\nBitte im Tab \"Planung\" Startdatum/Uhrzeiten setzen und \"Plan berechnen\" drücken.";
            AppendStatus("Fehler: " + msg.Replace("\n", " | "));
            System.Windows.MessageBox.Show(msg, "Planung", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
    }
}
        AppendStatus("Start…");
        try
        {
            await _orchestrator.RunAsync(Queue.ToList());
        }
        catch (Exception ex)
        {
            AppendStatus("Run abgebrochen: " + ex.Message);
            System.Windows.MessageBox.Show(ex.Message, "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Stop_Click(object sender, RoutedEventArgs e)
    {
        _orchestrator.RequestStop();
        AppendStatus("Stop angefordert…");
    }

    private void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveSettingsInternal();
            System.Windows.MessageBox.Show("Gespeichert.", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show(ex.Message, "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SaveSettingsInternal()
    {
        Settings.VideoFolder = VideoFolder;

        _settingsStore.Save(Settings);
    }


private void Plan_Click(object sender, RoutedEventArgs e)
{
    try
    {
        ApplyPlanningToQueue();
        AppendStatus("Plan berechnet.");
    }
    catch (Exception ex)
    {
        AppendStatus("Plan Fehler: " + ex.Message);
        System.Windows.MessageBox.Show(ex.Message, "Planung", MessageBoxButton.OK, MessageBoxImage.Error);
    }
}

private void PlanClear_Click(object sender, RoutedEventArgs e)
{
    foreach (var item in Queue)
    {
        item.PublishAtLocal = "";
    }
    for (int i = 0; i < Queue.Count; i++) Queue[i] = Queue[i];
    AppendStatus("Plan geleert.");
}

private void ApplyPlanningToQueue()
{
    if (!Settings.PlanningEnabled) return;
    if (Queue.Count == 0) return;

    var startDateText = (Settings.PlanningStartDate ?? "").Trim();
    if (string.IsNullOrWhiteSpace(startDateText))
        throw new Exception("Bitte ein Startdatum setzen (YYYY-MM-DD).");

    var startDate = DateTime.ParseExact(startDateText, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
    var days = Math.Max(1, Settings.PlanningDays);
    var perDay = Math.Max(1, Settings.PlanningVideosPerDay);

    var times = (Settings.PlanningTimesCsv ?? "")
        .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
        .Select(t => DateTime.ParseExact(t, "HH:mm", System.Globalization.CultureInfo.InvariantCulture).TimeOfDay)
        .ToList();

    if (times.Count == 0)
        throw new Exception("Bitte mindestens eine Uhrzeit angeben (z.B. 10:00,18:00).");

    int idx = 0;
    for (int d = 0; idx < Queue.Count; d++)
    {
        var date = startDate.Date.AddDays(d);
        for (int k = 0; k < perDay && idx < Queue.Count; k++)
        {
            var t = times[k % times.Count];
            var dt = date.Add(t);
            Queue[idx].PublishAtLocal = dt.ToString("yyyy-MM-dd HH:mm");
            idx++;
        }
        // stop after horizon only if user set finite; continue scheduling anyway to cover all queued items
        if (d + 1 >= days && idx >= Queue.Count) break;
    }

    for (int i = 0; i < Queue.Count; i++) Queue[i] = Queue[i];
}

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    private void TikTokClientSecretBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        Settings.TikTokClientSecret = TikTokClientSecretBox.Password;
    }

    private void RefreshTikTokTokenStatus()
{
    // Fire-and-forget async refresh so the UI never blocks.
    _ = RefreshTikTokTokenStatusAsync();
}

private async Task RefreshTikTokTokenStatusAsync()
{
    try
    {
        var store = new TikTokTokenStore();
        var b = store.Load();
        if (b == null)
        {
            TikTokTokenStatus = "(nicht eingeloggt)";
            return;
        }

        // If we have a refresh token and credentials, try to refresh silently when expired.
        if (!b.IsAccessTokenValid(TimeSpan.Zero) && b.HasRefresh
            && !string.IsNullOrWhiteSpace(Settings.TikTokClientKey)
            && !string.IsNullOrWhiteSpace(Settings.TikTokClientSecret))
        {
            try
            {
                var mgr = new TikTokTokenManager(store, new TikTokOAuthClient());
                await mgr.EnsureValidAccessTokenAsync(Settings, AppendStatus, CancellationToken.None);
                b = store.Load() ?? b;
            }
            catch (Exception ex)
            {
                AppendStatus("TikTok Token Refresh (Status) FEHLER: " + ex.Message);
            }
        }

        var expLocal = b.AccessTokenExpiresAtUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm");
        if (string.IsNullOrWhiteSpace(b.AccessToken))
        {
            TikTokTokenStatus = $"(ungültig: kein access_token) ({expLocal})";
            return;
        }

        // For display we use 0 skew; operational checks use a safety skew elsewhere.
        TikTokTokenStatus = b.IsAccessTokenValid(TimeSpan.Zero) ? $"OK bis {expLocal}" : $"abgelaufen ({expLocal})";
    }
    catch
    {
        TikTokTokenStatus = "(unbekannt)";
    }
}


    private async void TikTokLogin_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var store = new TikTokTokenStore();
            var oauth = new TikTokOAuthClient();

            AppendStatus("TikTok Login gestartet …");

            var bundle = await oauth.LoginDesktopAsync(
                Settings.TikTokClientKey,
                Settings.TikTokClientSecret,
                Settings.TikTokScopesCsv,
                Settings.TikTokRedirectHost,
                Settings.TikTokRedirectPort,
                Settings.TikTokRedirectPath,
                AppendStatus,
                CancellationToken.None);

            store.Save(bundle);
            // Verify persistence (helps diagnose DPAPI/path issues)
            var persisted = store.Load();
            if (persisted == null || string.IsNullOrWhiteSpace(persisted.AccessToken))
            {
                AppendStatus("TikTok WARN: Token nach Save nicht lesbar (kein access_token). Prüfe AppData/DPAPI.");
            }
            RefreshTikTokTokenStatus();
            AppendStatus("TikTok Login erfolgreich.");
        }
        catch (Exception ex)
        {
            AppendStatus("TikTok Login FEHLER: " + ex.Message);
            System.Windows.MessageBox.Show(ex.Message, "TikTok Login fehlgeschlagen", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void TikTokLogout_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var store = new TikTokTokenStore();
            store.Clear();
            RefreshTikTokTokenStatus();
            AppendStatus("TikTok Logout: Token gelöscht.");
        }
        catch (Exception ex)
        {
            AppendStatus("TikTok Logout FEHLER: " + ex.Message);
        }
    }

    private void TikTokPostPage_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var w = new TikTokPostWindow(() => Settings, SaveSettingsInternal, AppendStatus)
            {
                Owner = this
            };
            w.ShowDialog();
        }
        catch (Exception ex)
        {
            AppendStatus("TikTok Post-Seite FEHLER: " + ex.Message);
            System.Windows.MessageBox.Show(ex.Message, "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

}
