using System;
using System.Threading;
using System.Threading.Tasks;
using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public class TikTokTokenManager
{
    private readonly TikTokTokenStore _store;
    private readonly TikTokOAuthClient _oauth;

    public TikTokTokenManager(TikTokTokenStore store, TikTokOAuthClient oauth)
    {
        _store = store;
        _oauth = oauth;
    }

    public TikTokTokenBundle? Current => _store.Load();

    /// <summary>
    /// Ensures a valid access token. If the stored access token is expired and a refresh token exists,
    /// this method performs a refresh and persists the new token bundle.
    /// </summary>
    /// <summary>
    /// Backwards-compatible wrapper (older code expects this name).
    /// </summary>
    public Task<string> GetValidAccessTokenAsync(AppSettings settings, Action<string>? onStatus, CancellationToken ct)
        => EnsureValidAccessTokenAsync(settings, onStatus, ct);

    public async Task<string> EnsureValidAccessTokenAsync(
        AppSettings settings,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        var bundle = _store.Load();
        if (bundle == null)
            throw new Exception("TikTok: Kein Token vorhanden. Bitte einloggen.");

        if (bundle.IsAccessTokenValid())
            return bundle.AccessToken;

        if (!bundle.HasRefresh)
            throw new Exception("TikTok: Access Token abgelaufen und kein Refresh Token vorhanden. Bitte neu einloggen.");

        onStatus?.Invoke("TikTok: Access Token abgelaufen. Refresh wird durchgeführt …");
        var refreshed = await _oauth.RefreshAsync(
            settings.TikTokClientKey,
            settings.TikTokClientSecret,
            bundle.RefreshToken,
            onStatus,
            ct);

        // Some responses may not include a refresh_token; keep old refresh token if missing
        if (string.IsNullOrWhiteSpace(refreshed.RefreshToken))
            refreshed.RefreshToken = bundle.RefreshToken;

        _store.Save(refreshed);
        onStatus?.Invoke("TikTok: Token Refresh erfolgreich.");
        return refreshed.AccessToken;
    }
}