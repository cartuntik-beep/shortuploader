using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.YouTube.v3;
using Google.Apis.Upload;
using Google.Apis.Util.Store;

namespace ShortUploaderUI.Services;

public class YouTubeServiceWrapper
{
    private readonly YouTubeService _service;

    public YouTubeServiceWrapper(string clientSecretsFile, string tokenFile, Action<string> onStatus)
    {
        if (!File.Exists(clientSecretsFile))
            throw new FileNotFoundException("YouTube client secret JSON nicht gefunden.", clientSecretsFile);

        onStatus("YouTube: OAuth Login (Browser)…");

        using var stream = new FileStream(clientSecretsFile, FileMode.Open, FileAccess.Read);
        var credPath = Path.GetDirectoryName(tokenFile) ?? ".";

        // Store token in a file-backed data store (tokenFile as folder prefix)
        // We implement a small store that writes into the desired token file.
        var tokenStore = new SingleFileDataStore(tokenFile);

        var credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
            GoogleClientSecrets.FromStream(stream).Secrets,
            new[] { YouTubeService.Scope.YoutubeUpload },
            "user",
            CancellationToken.None,
            tokenStore
        ).GetAwaiter().GetResult();

        _service = new YouTubeService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential,
            ApplicationName = "ShortUploaderUI"
        });

        onStatus("YouTube: verbunden.");
    }

    public async Task<string> UploadAsync(string videoPath, string title, string description, string[] tags, string categoryId, string privacyStatus,
        DateTime? publishAtLocal, bool forcePrivate, Action<string> onStatus, CancellationToken ct)
    {
        onStatus($"YouTube: Upload startet ({Path.GetFileName(videoPath)})…");

        // Scheduling: publishAt can only be set if privacyStatus is private.
        if (publishAtLocal.HasValue)
        {
            privacyStatus = "private";
        }
        else if (forcePrivate)
        {
            privacyStatus = "private";
        }

        DateTimeOffset? publishAtUtc = null;
        if (publishAtLocal.HasValue)
        {
            var dtLocal = DateTime.SpecifyKind(publishAtLocal.Value, DateTimeKind.Unspecified);
            var dtoLocal = new DateTimeOffset(dtLocal, TimeZoneInfo.Local.GetUtcOffset(dtLocal));
            publishAtUtc = dtoLocal.ToUniversalTime();

            // If planned time is in the past (or too close), YouTube may publish immediately.
            var minUtc = DateTimeOffset.UtcNow.AddMinutes(3);
            if (publishAtUtc.Value < minUtc)
            {
                publishAtUtc = minUtc;
                onStatus($"YouTube: publishAt lag in der Vergangenheit/zu nah – auf {publishAtUtc:yyyy-MM-dd HH:mm} UTC korrigiert.");
            }
        }

        var video = new Google.Apis.YouTube.v3.Data.Video
        {
            Snippet = new Google.Apis.YouTube.v3.Data.VideoSnippet
            {
                Title = title,
                Description = description,
                Tags = tags?.ToList(),
                CategoryId = categoryId
            },
            Status = new Google.Apis.YouTube.v3.Data.VideoStatus
            {
                PrivacyStatus = privacyStatus,
                PublishAtDateTimeOffset = publishAtUtc
            }
        };

        using var fileStream = new FileStream(videoPath, FileMode.Open, FileAccess.Read);

        var insert = _service.Videos.Insert(video, "snippet,status", fileStream, "video/*");
        insert.ProgressChanged += p =>
        {
            if (p.Status == UploadStatus.Uploading && p.BytesSent > 0)
            {
                onStatus($"YouTube: Uploading… {p.BytesSent / (1024 * 1024)} MB");
            }
        };
        insert.ResponseReceived += v =>
        {
            // no-op
        };

        
var progress = await insert.UploadAsync(ct);

if (progress.Status == UploadStatus.Failed)
{
    var details = progress.Exception?.ToString() ?? "Unbekannter Fehler";
    throw new Exception("YouTube Upload fehlgeschlagen: " + details);
}

if (progress.Status != UploadStatus.Completed)
{
    throw new Exception($"YouTube Upload nicht abgeschlossen. Status: {progress.Status}");
}

var id = insert.ResponseBody?.Id;
if (string.IsNullOrWhiteSpace(id))
{
    throw new Exception("YouTube Upload abgeschlossen, aber keine Video-ID erhalten. Prüfe API-Response/Quota/Content Restrictions.");
}

onStatus($"YouTube: Upload OK (ID: {id})");

        if (publishAtUtc.HasValue)
        {
            onStatus($"YouTube: Geplante Veröffentlichung (UTC): {publishAtUtc:yyyy-MM-dd HH:mm}");
        }
        else if (forcePrivate)
        {
            onStatus("YouTube: Als PRIVATE hochgeladen (ohne publishAt). Du kannst später in YouTube Studio planen.");
        }
return id;
    }
}
