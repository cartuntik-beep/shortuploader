namespace ShortUploaderUI.Services;

public static class FileScanner
{
    public static List<string> ListVideos(string folder, IEnumerable<string> exts)
    {
        var set = new HashSet<string>(exts.Select(e => e.ToLowerInvariant()));
        var files = Directory.EnumerateFiles(folder)
            .Where(p => set.Contains(Path.GetExtension(p).ToLowerInvariant()))
            .OrderBy(p => p)
            .ToList();
        return files;
    }
}
