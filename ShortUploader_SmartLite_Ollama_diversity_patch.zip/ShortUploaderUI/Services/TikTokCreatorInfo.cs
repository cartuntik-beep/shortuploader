using System.Text.Json;

namespace ShortUploaderUI.Services;

public sealed class TikTokCreatorInfo
{
    public string Nickname { get; init; } = "";
    public string Username { get; init; } = "";

    /// <summary>
    /// Maximum allowed video duration (seconds) returned by creator_info/query.
    /// 0 means unknown.
    /// </summary>
    public int MaxVideoPostDurationSec { get; init; } = 0;

    public IReadOnlyList<string> PrivacyLevelOptions { get; init; } = Array.Empty<string>();

    public bool CommentDisabledInApp { get; init; } = false;
    public bool DuetDisabledInApp { get; init; } = false;
    public bool StitchDisabledInApp { get; init; } = false;

    public bool CanPost { get; init; } = true;
    public string? CanPostReason { get; init; }

    public static TikTokCreatorInfo FromCreatorInfoResponse(string json)
    {
        using var doc = JsonDocument.Parse(json);

        // TikTok wrappers typically look like {"error":{...}, "data":{...}}
        var root = doc.RootElement;
        JsonElement data;
        if (root.TryGetProperty("data", out var d)) data = d;
        else data = root;

        string GetString(params string[] keys)
        {
            foreach (var k in keys)
            {
                if (data.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String)
                    return v.GetString() ?? "";
            }
            return "";
        }

        int GetInt(params string[] keys)
        {
            foreach (var k in keys)
            {
                if (data.TryGetProperty(k, out var v))
                {
                    if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var n)) return n;
                    if (v.ValueKind == JsonValueKind.String && int.TryParse(v.GetString(), out var s)) return s;
                }
            }
            return 0;
        }

        bool GetBool(params string[] keys)
        {
            foreach (var k in keys)
            {
                if (data.TryGetProperty(k, out var v))
                {
                    if (v.ValueKind == JsonValueKind.True) return true;
                    if (v.ValueKind == JsonValueKind.False) return false;
                    if (v.ValueKind == JsonValueKind.Number && v.TryGetInt32(out var n)) return n != 0;
                    if (v.ValueKind == JsonValueKind.String && bool.TryParse(v.GetString(), out var b)) return b;
                }
            }
            return false;
        }

        var options = new List<string>();
        if (data.TryGetProperty("privacy_level_options", out var arr) && arr.ValueKind == JsonValueKind.Array)
        {
            foreach (var el in arr.EnumerateArray())
            {
                if (el.ValueKind == JsonValueKind.String) options.Add(el.GetString() ?? "");
            }
        }

        // Some payloads may nest options under "privacy".
        if (options.Count == 0 && data.TryGetProperty("privacy", out var p) && p.ValueKind == JsonValueKind.Object)
        {
            if (p.TryGetProperty("privacy_level_options", out var arr2) && arr2.ValueKind == JsonValueKind.Array)
            {
                foreach (var el in arr2.EnumerateArray())
                    if (el.ValueKind == JsonValueKind.String) options.Add(el.GetString() ?? "");
            }
        }

        // can_post signals
        var canPost = true;
        string? canPostReason = null;
        if (data.TryGetProperty("can_post", out var cp))
        {
            if (cp.ValueKind == JsonValueKind.False) canPost = false;
            if (cp.ValueKind == JsonValueKind.True) canPost = true;
        }
        if (data.TryGetProperty("can_post_reason", out var cpr) && cpr.ValueKind == JsonValueKind.String)
        {
            canPostReason = cpr.GetString();
        }
        if (data.TryGetProperty("post_restriction", out var pr) && pr.ValueKind == JsonValueKind.Object)
        {
            if (pr.TryGetProperty("can_post", out var cp2) && cp2.ValueKind == JsonValueKind.False)
                canPost = false;
            if (pr.TryGetProperty("reason", out var r) && r.ValueKind == JsonValueKind.String)
                canPostReason = r.GetString();
        }

        return new TikTokCreatorInfo
        {
            Nickname = GetString("creator_nickname", "nickname"),
            Username = GetString("creator_username", "username"),
            MaxVideoPostDurationSec = GetInt("max_video_post_duration_sec", "max_video_duration_sec"),
            PrivacyLevelOptions = options,
            CommentDisabledInApp = GetBool("comment_disabled", "disable_comment"),
            DuetDisabledInApp = GetBool("duet_disabled", "disable_duet"),
            StitchDisabledInApp = GetBool("stitch_disabled", "disable_stitch"),
            CanPost = canPost,
            CanPostReason = canPostReason
        };
    }
}
