using ShortUploaderUI.Models;
using System.Text.Json;

namespace ShortUploaderUI.Services;

public class SettingsStore
{
    private readonly string _path;

    public SettingsStore(string path)
    {
        _path = path;
    }

    public AppSettings LoadOrCreateDefault()
    {
        if (!File.Exists(_path))
        {
            var d = new AppSettings();
            Save(d);
            return d;
        }

        var json = File.ReadAllText(_path);
        var settings = JsonSerializer.Deserialize<AppSettings>(json) ?? new AppSettings();
        return settings;
    }

    public void Save(AppSettings settings)
    {
        var json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(_path, json);
    }
}
