using System.Diagnostics;
using System.Globalization;
using System.IO;
using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public static class FrameExtractor
{
    public static string ResolveFfmpegPath(AppSettings settings)
    {
        if (!string.IsNullOrWhiteSpace(settings.SmartLiteFfmpegPath) && File.Exists(settings.SmartLiteFfmpegPath))
            return settings.SmartLiteFfmpegPath;

        // Try alongside executable: tools\ffmpeg\ffmpeg.exe
        var baseDir = AppContext.BaseDirectory;
        var candidate = Path.Combine(baseDir, "tools", "ffmpeg", "ffmpeg.exe");
        if (File.Exists(candidate)) return candidate;

        // Fallback: rely on PATH
        return "ffmpeg";
    }

    public static string ResolveFfprobePath(AppSettings settings)
    {
        if (!string.IsNullOrWhiteSpace(settings.SmartLiteFfprobePath) && File.Exists(settings.SmartLiteFfprobePath))
            return settings.SmartLiteFfprobePath;

        var baseDir = AppContext.BaseDirectory;
        var candidate = Path.Combine(baseDir, "tools", "ffmpeg", "ffprobe.exe");
        if (File.Exists(candidate)) return candidate;

        return "ffprobe";
    }

    public static async Task<double> GetDurationSecondsAsync(string videoPath, AppSettings settings, CancellationToken ct)
    {
        var ffprobe = ResolveFfprobePath(settings);
        var psi = new ProcessStartInfo
        {
            FileName = ffprobe,
            Arguments = $"-v error -show_entries format=duration -of default=nk=1:nw=1 \"{videoPath}\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        };
        using var proc = Process.Start(psi) ?? throw new InvalidOperationException("Failed to start ffprobe.");
        var output = await proc.StandardOutput.ReadToEndAsync();
        var err = await proc.StandardError.ReadToEndAsync();
        await proc.WaitForExitAsync(ct);
        if (proc.ExitCode != 0)
            throw new InvalidOperationException($"ffprobe failed (exit {proc.ExitCode}): {err}");

        if (!double.TryParse(output.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out var seconds))
            throw new InvalidOperationException($"ffprobe returned invalid duration: '{output.Trim()}'");
        return seconds;
    }

    public static async Task<List<string>> ExtractJpegFramesAsync(
        string videoPath,
        string outDir,
        AppSettings settings,
        int frames,
        CancellationToken ct)
    {
        Directory.CreateDirectory(outDir);
        var duration = await GetDurationSecondsAsync(videoPath, settings, ct);
        if (duration <= 0.2)
            throw new InvalidOperationException("Video duration is too short.");

        frames = Math.Max(3, Math.Min(frames, 30));

        // Generate timestamps (avoid first/last 0.0s edge)
        var timestamps = new List<double>();
        for (int i = 0; i < frames; i++)
        {
            var frac = (i + 1.0) / (frames + 1.0);
            timestamps.Add(duration * frac);
        }

        var ffmpeg = ResolveFfmpegPath(settings);
        var results = new List<string>();

        int idx = 0;
        foreach (var ts in timestamps)
        {
            ct.ThrowIfCancellationRequested();
            idx++;
            var outPath = Path.Combine(outDir, $"frame_{idx:00}.jpg");

            // -ss before -i for fast seeking, -frames:v 1 for single frame
            var psi = new ProcessStartInfo
            {
                FileName = ffmpeg,
                Arguments = $"-y -ss {ts.ToString("0.###", CultureInfo.InvariantCulture)} -i \"{videoPath}\" -frames:v 1 -vf scale=640:-1 -q:v 3 \"{outPath}\"",
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using var proc = Process.Start(psi) ?? throw new InvalidOperationException("Failed to start ffmpeg.");
            var err = await proc.StandardError.ReadToEndAsync();
            await proc.WaitForExitAsync(ct);
            if (proc.ExitCode != 0 || !File.Exists(outPath))
                throw new InvalidOperationException($"ffmpeg frame extraction failed (exit {proc.ExitCode}): {err}");

            results.Add(outPath);
        }

        return results;
    }
}
