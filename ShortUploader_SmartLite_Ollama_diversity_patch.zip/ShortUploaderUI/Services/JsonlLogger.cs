using System.Text.Json;

namespace ShortUploaderUI.Services;

public class JsonlLogger
{
    private readonly string _path;
    private readonly object _lock = new();

    public JsonlLogger(string logsDir)
    {
        Directory.CreateDirectory(logsDir);
        _path = Path.Combine(logsDir, "uploader.jsonl");
    }

    public void Log(string evt, object payload)
    {
        var record = new Dictionary<string, object?>
        {
            ["ts"] = DateTime.UtcNow.ToString("o"),
            ["event"] = evt,
            ["payload"] = payload
        };

        var line = JsonSerializer.Serialize(record);
        lock (_lock)
        {
            File.AppendAllText(_path, line + Environment.NewLine);
        }
    }
}
