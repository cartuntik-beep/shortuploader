using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace ShortUploaderUI.Services;

public class TikTokServiceWrapper
{
    private readonly HttpClient _http;
    private readonly string _accessToken;

    public TikTokServiceWrapper(string accessToken)
    {
        _accessToken = accessToken?.Trim() ?? "";
        if (string.IsNullOrWhiteSpace(_accessToken))
            throw new Exception("TikTok Access Token fehlt.");

        _http = new HttpClient
        {
            BaseAddress = new Uri("https://open.tiktokapis.com/")
        };
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);
    }

    /// <summary>
    /// Retrieves the latest creator info required for UX compliance.
    /// </summary>
    public async Task<TikTokCreatorInfo> QueryCreatorInfoAsync(CancellationToken ct)
    {
        var res = await _http.PostAsync("v2/post/publish/creator_info/query/",
            new StringContent("{}", Encoding.UTF8, "application/json"), ct);

        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new Exception($"TikTok creator_info HTTP {(int)res.StatusCode}: {body}");

        // Most responses include an error wrapper.
        using (var doc = JsonDocument.Parse(body))
        {
            if (doc.RootElement.TryGetProperty("error", out var err)
                && err.ValueKind == JsonValueKind.Object
                && err.TryGetProperty("code", out var codeEl)
                && codeEl.ValueKind == JsonValueKind.String)
            {
                var code = codeEl.GetString() ?? "";
                if (!string.Equals(code, "ok", StringComparison.OrdinalIgnoreCase))
                    throw new Exception($"TikTok creator_info error: {body}");
            }
        }

        return TikTokCreatorInfo.FromCreatorInfoResponse(body);
    }

    public Task<(string publishId, string? uploadUrl)> InitAsync(
        string videoPath,
        string caption,
        string privacyLevel,
        bool isAigc,
        bool disableComment,
        bool disableDuet,
        bool disableStitch,
        int coverTimestampMs,
        int chunkSize,
        CancellationToken ct)
        => InitAsync(videoPath, caption, privacyLevel, isAigc, disableComment, disableDuet, disableStitch, coverTimestampMs, chunkSize,
            brandContentToggle: false, brandOrganicToggle: false, ct: ct);

    public async Task<(string publishId, string? uploadUrl)> InitAsync(
        string videoPath,
        string caption,
        string privacyLevel,
        bool isAigc,
        bool disableComment,
        bool disableDuet,
        bool disableStitch,
        int coverTimestampMs,
        int chunkSize,
        bool brandContentToggle,
        bool brandOrganicToggle,
        CancellationToken ct)
    {
        var size = new FileInfo(videoPath).Length;

        // TikTok chunk rules (Content Posting API):
        // - If video_size <= 64MB: upload as a whole (chunk_size = video_size, total_chunk_count = 1)
        // - If video_size > 64MB: chunk_size must be between 5MB and 64MB; ensure last chunk is >= 5MB
        const long MB = 1024L * 1024L;
        long chunk = chunkSize > 0 ? chunkSize : 10_000_000;

        if (size <= 64L * MB)
        {
            chunk = size; // whole upload
        }
        else
        {
            // Clamp to allowed range for non-final chunks
            chunk = Math.Max(5L * MB, Math.Min(64L * MB, chunk));

            // Compute chunk count (ceiling) and force multiple chunks for >64MB
            long total = (size + chunk - 1) / chunk;
            if (total < 2) total = 2;

            // Adjust chunk size to make last chunk >= 5MB (TikTok requirement)
            for (int i = 0; i < 4; i++)
            {
                chunk = (size + total - 1) / total; // approx equal split
                chunk = Math.Max(5L * MB, Math.Min(64L * MB, chunk));
                long remainder = size - (total - 1) * chunk;
                if (remainder >= 5L * MB) break;

                // Make remainder at least 5MB by slightly reducing chunk size
                long delta = (5L * MB) - remainder;
                chunk = Math.Max(5L * MB, chunk - delta);
            }
        }

        var totalChunks = (size + chunk - 1) / chunk;
        if (size > 64L * MB && totalChunks < 2) totalChunks = 2;

        int effectiveChunkSize = (int)Math.Min(int.MaxValue, chunk);


        // TikTok requires certain post_info fields to be present even when they are false.
        // Also, privacy_level must be one of the documented enums (and ideally match creator_info/query options).
        if (string.IsNullOrWhiteSpace(privacyLevel))
            privacyLevel = "SELF_ONLY";

        // Defensive: if UI provides an unexpected value, fall back to SELF_ONLY.
        // This avoids 400 invalid_params for post_info.
        var allowedPrivacy = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "PUBLIC_TO_EVERYONE",
            "MUTUAL_FOLLOW_FRIENDS",
            "FOLLOWER_OF_CREATOR",
            "SELF_ONLY"
        };
        if (!allowedPrivacy.Contains(privacyLevel))
            privacyLevel = "SELF_ONLY";

        var payload = new
        {
            post_info = new
            {
                title = caption,
                privacy_level = privacyLevel,
                disable_comment = disableComment,
                disable_duet = disableDuet,
                disable_stitch = disableStitch,
                video_cover_timestamp_ms = coverTimestampMs,
                // These toggles are required by TikTok's schema.
                brand_content_toggle = brandContentToggle,
                brand_organic_toggle = brandOrganicToggle,
                is_aigc = isAigc
            },
            source_info = new
            {
                source = "FILE_UPLOAD",
                video_size = size,
                chunk_size = effectiveChunkSize,
                total_chunk_count = totalChunks
            }
        };

        var json = JsonSerializer.Serialize(payload);
        var res = await _http.PostAsync("v2/post/publish/video/init/",
            new StringContent(json, Encoding.UTF8, "application/json"), ct);

        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new Exception($"TikTok init HTTP {(int)res.StatusCode}: {body}");

        using var doc = JsonDocument.Parse(body);
        var errorCode = doc.RootElement.GetProperty("error").GetProperty("code").GetString();
        if (!string.Equals(errorCode, "ok", StringComparison.OrdinalIgnoreCase))
            throw new Exception($"TikTok init error: {body}");

        var data = doc.RootElement.GetProperty("data");
        var publishId = data.GetProperty("publish_id").GetString() ?? "";
        var uploadUrl = data.TryGetProperty("upload_url", out var u) ? u.GetString() : null;

        return (publishId, uploadUrl);
    }

    public async Task UploadPutAsync(string uploadUrl, string videoPath, CancellationToken ct)
    {
        var bytes = await File.ReadAllBytesAsync(videoPath, ct);
        var size = bytes.Length;

        using var req = new HttpRequestMessage(HttpMethod.Put, uploadUrl);
        req.Content = new ByteArrayContent(bytes);
        req.Content.Headers.ContentType = new MediaTypeHeaderValue("video/mp4");
        req.Content.Headers.ContentLength = size;
        req.Headers.TryAddWithoutValidation("Content-Range", $"bytes 0-{size - 1}/{size}");

        using var client = new HttpClient();
        var res = await client.SendAsync(req, ct);
        if ((int)res.StatusCode is not (200 or 201 or 204))
        {
            var txt = await res.Content.ReadAsStringAsync(ct);
            throw new Exception($"TikTok PUT HTTP {(int)res.StatusCode}: {txt}");
        }
    }

    public async Task<(string status, string? failReason)> FetchStatusAsync(string publishId, CancellationToken ct)
    {
        var payload = JsonSerializer.Serialize(new { publish_id = publishId });
        var res = await _http.PostAsync("v2/post/publish/status/fetch/",
            new StringContent(payload, Encoding.UTF8, "application/json"), ct);

        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new Exception($"TikTok status HTTP {(int)res.StatusCode}: {body}");

        using var doc = JsonDocument.Parse(body);
        var errorCode = doc.RootElement.GetProperty("error").GetProperty("code").GetString();
        if (!string.Equals(errorCode, "ok", StringComparison.OrdinalIgnoreCase))
            throw new Exception($"TikTok status error: {body}");

        var data = doc.RootElement.GetProperty("data");
        var status = data.TryGetProperty("status", out var s) ? s.GetString() ?? "" : "";
        var fail = data.TryGetProperty("fail_reason", out var f) ? f.GetString() : null;
        return (status, fail);
    }

    public async Task WaitUntilCompleteAsync(string publishId, Action<string> onStatus, CancellationToken ct, int maxWaitSeconds = 300)
    {
        var start = DateTime.UtcNow;
        while (true)
        {
            ct.ThrowIfCancellationRequested();
            var (status, fail) = await FetchStatusAsync(publishId, ct);
            onStatus($"TikTok: Status {status}");

            if (status == "PUBLISH_COMPLETE") return;
            if (status == "FAILED") throw new Exception($"TikTok FAILED: {fail}");

            if ((DateTime.UtcNow - start).TotalSeconds > maxWaitSeconds)
                throw new Exception("TikTok Timeout beim Warten auf Status.");

            await Task.Delay(TimeSpan.FromSeconds(3), ct);
        }
    }
}
