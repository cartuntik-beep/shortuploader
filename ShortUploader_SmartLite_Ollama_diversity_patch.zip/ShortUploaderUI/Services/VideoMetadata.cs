using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;

namespace ShortUploaderUI.Services;

public static class VideoMetadata
{
    /// <summary>
    /// Attempts to get video duration in seconds using WPF MediaPlayer.
    /// Returns null if duration cannot be determined quickly.
    /// </summary>
    public static async Task<int?> TryGetDurationSecondsAsync(string filePath, int timeoutMs = 4000)
    {
        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            return null;

        var tcs = new TaskCompletionSource<int?>(TaskCreationOptions.RunContinuationsAsynchronously);

        MediaPlayer? player = null;
        try
        {
            player = new MediaPlayer();
            player.MediaOpened += (_, __) =>
            {
                try
                {
                    if (player.NaturalDuration.HasTimeSpan)
                    {
                        var secs = (int)Math.Round(player.NaturalDuration.TimeSpan.TotalSeconds);
                        tcs.TrySetResult(Math.Max(0, secs));
                    }
                    else
                    {
                        tcs.TrySetResult(null);
                    }
                }
                catch
                {
                    tcs.TrySetResult(null);
                }
            };
            player.MediaFailed += (_, __) => tcs.TrySetResult(null);

            player.Open(new Uri(filePath, UriKind.Absolute));
            player.Play();
            player.Pause();

            using var cts = new CancellationTokenSource(timeoutMs);
            await using (cts.Token.Register(() => tcs.TrySetResult(null)))
            {
                return await tcs.Task;
            }
        }
        finally
        {
            try { player?.Close(); } catch { /* ignore */ }
        }
    }
}
