using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public class TikTokOAuthClient
{
    private const string AuthorizeEndpoint = "https://www.tiktok.com/v2/auth/authorize/";
    private const string TokenEndpoint = "https://open.tiktokapis.com/v2/oauth/token/";

    public async Task<TikTokTokenBundle> LoginDesktopAsync(
        string clientKey,
        string clientSecret,
        string scopesCsv,
        string redirectHost,
        int redirectPort,
        string redirectPath,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(clientKey)) throw new Exception("TikTok Client Key fehlt.");
        if (string.IsNullOrWhiteSpace(clientSecret)) throw new Exception("TikTok Client Secret fehlt.");
        if (string.IsNullOrWhiteSpace(scopesCsv)) throw new Exception("TikTok Scopes fehlen.");

        var scopes = scopesCsv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (scopes.Length == 0) throw new Exception("TikTok Scopes fehlen.");

        var state = Guid.NewGuid().ToString("N");
        var verifier = GenerateCodeVerifier();
        var challenge = GenerateCodeChallenge(verifier);

        var port = redirectPort == 0 ? GetFreePort() : redirectPort;
        var path = string.IsNullOrWhiteSpace(redirectPath) ? "/callback/" : redirectPath;
        if (!path.EndsWith('/')) path += "/";

        var redirectUri = $"http://{redirectHost}:{port}{path}";
        onStatus?.Invoke($"TikTok OAuth Redirect: {redirectUri}");

        using var listener = new HttpListener();
        listener.Prefixes.Add(redirectUri);
        listener.Start();

        var authorizeUrl = BuildAuthorizeUrl(clientKey, redirectUri, scopes, state, challenge);
        onStatus?.Invoke("Öffne TikTok Login im Browser …");

        Process.Start(new ProcessStartInfo
        {
            FileName = authorizeUrl,
            UseShellExecute = true
        });

        // Wait for callback
        var ctxTask = listener.GetContextAsync();
        using (ct.Register(() => { try { listener.Stop(); } catch { } }))
        {
            var ctx = await ctxTask;
            var qs = ctx.Request.QueryString;

            var returnedState = qs["state"];
            // TikTok docs: the authorization code should be URL-decoded before use.
            // HttpListener often decodes query parameters already, but we defensively unescape again
            // to avoid edge cases (e.g. '+' vs '%2B', double-encoding, etc.).
            var code = qs["code"];
            if (!string.IsNullOrWhiteSpace(code))
                code = Uri.UnescapeDataString(code);

            var error = qs["error"];
            if (!string.IsNullOrWhiteSpace(error))
                error = Uri.UnescapeDataString(error);

            var html = "<html><body><h3>Login erfolgreich.</h3><p>Du kannst dieses Fenster schließen.</p></body></html>";
            if (!string.IsNullOrWhiteSpace(error) || string.IsNullOrWhiteSpace(code))
            {
                html = "<html><body><h3>Login fehlgeschlagen.</h3><p>Bitte zur App zurückkehren.</p></body></html>";
            }

            var bytes = Encoding.UTF8.GetBytes(html);
            ctx.Response.ContentType = "text/html; charset=utf-8";
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.Close();

            if (returnedState != state) throw new Exception("TikTok OAuth: state mismatch.");
            if (!string.IsNullOrWhiteSpace(error)) throw new Exception($"TikTok OAuth error: {error}");
            if (string.IsNullOrWhiteSpace(code)) throw new Exception("TikTok OAuth: code fehlt.");

            onStatus?.Invoke("TikTok OAuth Code erhalten. Tausche gegen Token …");

            return await ExchangeCodeAsync(clientKey, clientSecret, redirectUri, code, verifier, onStatus, ct);
        }
    }

    public async Task<TikTokTokenBundle> RefreshAsync(
        string clientKey,
        string clientSecret,
        string refreshToken,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(clientKey)) throw new Exception("TikTok Client Key fehlt.");
        if (string.IsNullOrWhiteSpace(clientSecret)) throw new Exception("TikTok Client Secret fehlt.");
        if (string.IsNullOrWhiteSpace(refreshToken)) throw new Exception("TikTok Refresh Token fehlt. Bitte erneut einloggen.");

        onStatus?.Invoke("TikTok: Refresh Token …");

        using var http = new HttpClient();
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_key"] = clientKey.Trim(),
            ["client_secret"] = clientSecret.Trim(),
            ["grant_type"] = "refresh_token",
            ["refresh_token"] = refreshToken.Trim()
        });

        var res = await http.PostAsync(TokenEndpoint, form, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new Exception($"TikTok Token Refresh HTTP {(int)res.StatusCode}: {body}");

        return ParseTokenResponse(body);
    }

    private static string BuildAuthorizeUrl(string clientKey, string redirectUri, string[] scopes, string state, string challenge)
    {
        var sb = new StringBuilder();
        sb.Append(AuthorizeEndpoint);
        sb.Append("?client_key=").Append(Uri.EscapeDataString(clientKey.Trim()));
        sb.Append("&response_type=code");
        sb.Append("&scope=").Append(Uri.EscapeDataString(string.Join(",", scopes)));
        sb.Append("&redirect_uri=").Append(Uri.EscapeDataString(redirectUri));
        sb.Append("&state=").Append(Uri.EscapeDataString(state));
        sb.Append("&code_challenge=").Append(Uri.EscapeDataString(challenge));
        sb.Append("&code_challenge_method=S256");
        return sb.ToString();
    }

    private static async Task<TikTokTokenBundle> ExchangeCodeAsync(
        string clientKey,
        string clientSecret,
        string redirectUri,
        string code,
        string verifier,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        using var http = new HttpClient();
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_key"] = clientKey.Trim(),
            ["client_secret"] = clientSecret.Trim(),
            ["grant_type"] = "authorization_code",
            ["code"] = code.Trim(),
            ["redirect_uri"] = redirectUri,
            ["code_verifier"] = verifier
        });

        var res = await http.PostAsync(TokenEndpoint, form, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new Exception($"TikTok Token HTTP {(int)res.StatusCode}: {body}");

        // TikTok sometimes returns HTTP 200 with an error payload. Validate content.
        var bundle = ParseTokenResponse(body);
        var apiError = TryExtractApiError(body);
        if (!string.IsNullOrWhiteSpace(apiError))
        {
            onStatus?.Invoke("TikTok Token FEHLER (API): " + apiError);
            throw new Exception("TikTok Token API error: " + apiError);
        }

        if (string.IsNullOrWhiteSpace(bundle.AccessToken))
        {
            // Avoid leaking secrets; include only a short snippet for diagnosis.
            var snippet = body.Length > 500 ? body[..500] + "…" : body;
            onStatus?.Invoke("TikTok Token FEHLER: access_token fehlt. Response-Snippet: " + snippet);
            throw new Exception("TikTok Token response missing access_token.");
        }

        onStatus?.Invoke("TikTok Token erhalten.");
        return bundle;
    }

    private static string? TryExtractApiError(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            // Prefer TikTok's documented error format:
            // {"error":"invalid_request","error_description":"...","log_id":"..."}
            if (root.ValueKind == JsonValueKind.Object)
            {
                string? err = null;
                string? errDesc = null;
                if (root.TryGetProperty("error", out var e0) && e0.ValueKind == JsonValueKind.String)
                    err = e0.GetString();
                if (root.TryGetProperty("error_description", out var ed0) && ed0.ValueKind == JsonValueKind.String)
                    errDesc = ed0.GetString();

                if (!string.IsNullOrWhiteSpace(err) && !string.IsNullOrWhiteSpace(errDesc))
                    return err + ": " + errDesc;
                if (!string.IsNullOrWhiteSpace(err))
                    return err;
                if (!string.IsNullOrWhiteSpace(errDesc))
                    return errDesc;
            }

            // Common patterns: {"message":"...","data":{"error_code":...,"description":"..."}}
            string? message = null;
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("message", out var m) && m.ValueKind == JsonValueKind.String)
                message = m.GetString();

            JsonElement data;
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("data", out data) && data.ValueKind == JsonValueKind.Object)
            {
                // If TikTok uses an error object inside data
                if (data.TryGetProperty("error", out var err) && err.ValueKind == JsonValueKind.String)
                    return err.GetString();

                if (data.TryGetProperty("error_description", out var ed) && ed.ValueKind == JsonValueKind.String)
                    return ed.GetString();

                if (data.TryGetProperty("description", out var desc) && desc.ValueKind == JsonValueKind.String)
                    return desc.GetString();

                if (data.TryGetProperty("error_code", out var ec))
                {
                    var ecStr = ec.ValueKind == JsonValueKind.Number ? ec.GetRawText() : (ec.ValueKind == JsonValueKind.String ? ec.GetString() : null);
                    if (!string.IsNullOrWhiteSpace(ecStr) && !string.Equals(ecStr, "0", StringComparison.OrdinalIgnoreCase))
                    {
                        // If message is 'ok' but error_code != 0, treat as error.
                        var extra = "";
                        if (!string.IsNullOrWhiteSpace(message) && !string.Equals(message, "ok", StringComparison.OrdinalIgnoreCase))
                            extra = " (" + message + ")";
                        return "error_code=" + ecStr + extra;
                    }
                }
            }

            // Some payloads use top-level error fields (handled above), keep as fallback.
            if (root.ValueKind == JsonValueKind.Object)
            {
                if (root.TryGetProperty("error", out var e) && e.ValueKind == JsonValueKind.String)
                    return e.GetString();
                if (root.TryGetProperty("error_description", out var ed2) && ed2.ValueKind == JsonValueKind.String)
                    return ed2.GetString();
            }

            // If message exists and is not ok, return it.
            if (!string.IsNullOrWhiteSpace(message) && !string.Equals(message, "ok", StringComparison.OrdinalIgnoreCase))
                return message;
        }
        catch { }

        return null;
    }

    private static TikTokTokenBundle ParseTokenResponse(string json)
    {
        using var doc = JsonDocument.Parse(json);

        // TikTok typically returns: { "data": { ... }, "message": "ok" }
        // Some error payloads differ, so we parse defensively.
        var root0 = doc.RootElement;

        JsonElement? data = null;
        if (root0.ValueKind == JsonValueKind.Object && root0.TryGetProperty("data", out var d))
            data = d;

        // Helper: read string property from either data or root, then fallback to deep search
        static string GetStringLoose(JsonElement? primary, JsonElement root, string name)
        {
            if (primary.HasValue && primary.Value.ValueKind == JsonValueKind.Object && primary.Value.TryGetProperty(name, out var p1) && p1.ValueKind == JsonValueKind.String)
                return p1.GetString() ?? "";
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var p2) && p2.ValueKind == JsonValueKind.String)
                return p2.GetString() ?? "";

            // Deep search (handles unexpected nesting)
            if (primary.HasValue)
            {
                var s = DeepFindString(primary.Value, name);
                if (!string.IsNullOrWhiteSpace(s)) return s;
            }
            return DeepFindString(root, name);
        }

        static int GetIntLoose(JsonElement? primary, JsonElement root, string name)
        {
            if (primary.HasValue && primary.Value.ValueKind == JsonValueKind.Object && primary.Value.TryGetProperty(name, out var p1))
            {
                if (p1.ValueKind == JsonValueKind.Number && p1.TryGetInt32(out var n1)) return n1;
                if (p1.ValueKind == JsonValueKind.String && int.TryParse(p1.GetString(), out var n1s)) return n1s;
            }
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty(name, out var p2))
            {
                if (p2.ValueKind == JsonValueKind.Number && p2.TryGetInt32(out var n2)) return n2;
                if (p2.ValueKind == JsonValueKind.String && int.TryParse(p2.GetString(), out var n2s)) return n2s;
            }

            if (primary.HasValue)
            {
                var s = DeepFindString(primary.Value, name);
                if (int.TryParse(s, out var dn)) return dn;
            }
            var s2 = DeepFindString(root, name);
            return int.TryParse(s2, out var dn2) ? dn2 : 0;
        }

        static string? DeepFindString(JsonElement el, string name)
        {
            try
            {
                if (el.ValueKind == JsonValueKind.Object)
                {
                    foreach (var prop in el.EnumerateObject())
                    {
                        if (string.Equals(prop.Name, name, StringComparison.OrdinalIgnoreCase))
                        {
                            if (prop.Value.ValueKind == JsonValueKind.String) return prop.Value.GetString();
                            if (prop.Value.ValueKind == JsonValueKind.Number) return prop.Value.GetRawText();
                        }

                        var child = DeepFindString(prop.Value, name);
                        if (!string.IsNullOrWhiteSpace(child)) return child;
                    }
                }
                else if (el.ValueKind == JsonValueKind.Array)
                {
                    foreach (var item in el.EnumerateArray())
                    {
                        var child = DeepFindString(item, name);
                        if (!string.IsNullOrWhiteSpace(child)) return child;
                    }
                }
            }
            catch { /* ignore */ }

            return null;
        }

        var access = GetStringLoose(data, root0, "access_token");
        if (string.IsNullOrWhiteSpace(access)) access = GetStringLoose(data, root0, "accessToken");
        var refresh = GetStringLoose(data, root0, "refresh_token");
        if (string.IsNullOrWhiteSpace(refresh)) refresh = GetStringLoose(data, root0, "refreshToken");

        var expiresIn = GetIntLoose(data, root0, "expires_in");
        if (expiresIn <= 0) expiresIn = GetIntLoose(data, root0, "expiresIn");
        var refreshExpiresIn = GetIntLoose(data, root0, "refresh_expires_in");
        if (refreshExpiresIn <= 0) refreshExpiresIn = GetIntLoose(data, root0, "refreshExpiresIn");

        var openId = GetStringLoose(data, root0, "open_id");
        if (string.IsNullOrWhiteSpace(openId)) openId = GetStringLoose(data, root0, "openId");
        var scope = GetStringLoose(data, root0, "scope");
        if (string.IsNullOrWhiteSpace(scope)) scope = GetStringLoose(data, root0, "scopes");
        var tokenType = GetStringLoose(data, root0, "token_type");
        if (string.IsNullOrWhiteSpace(tokenType)) tokenType = GetStringLoose(data, root0, "tokenType");

        // Compute expiries defensively. If expires_in is missing, assume 1 hour to avoid "immediately expired" state.
        var now = DateTimeOffset.UtcNow;
        var effectiveExpires = expiresIn > 0 ? expiresIn : 3600;
        var effectiveRefreshExpires = refreshExpiresIn > 0 ? refreshExpiresIn : 0;

        // Store the *actual* expiry in UTC. Apply any safety margin only when validating.
        // This avoids edge cases where small expires_in values would appear immediately expired.
        var accessExp = now.AddSeconds(Math.Max(0, effectiveExpires));

        DateTimeOffset? refreshExp = null;
        if (effectiveRefreshExpires > 0)
            refreshExp = now.AddSeconds(Math.Max(0, effectiveRefreshExpires));

        return new TikTokTokenBundle
        {
            AccessToken = access ?? "",
            RefreshToken = refresh ?? "",
            AccessTokenExpiresAtUtc = accessExp,
            RefreshTokenExpiresAtUtc = refreshExp,
            OpenId = string.IsNullOrWhiteSpace(openId) ? null : openId,
            Scope = string.IsNullOrWhiteSpace(scope) ? null : scope,
            TokenType = string.IsNullOrWhiteSpace(tokenType) ? null : tokenType
        };
    }


    private static int GetFreePort()
    {
        var l = new System.Net.Sockets.TcpListener(IPAddress.Loopback, 0);
        l.Start();
        var port = ((IPEndPoint)l.LocalEndpoint).Port;
        l.Stop();
        return port;
    }

    private static string GenerateCodeVerifier()
    {
		// PKCE verifier must be 43-128 chars (RFC 7636) from the *unreserved* set.
		// TikTok's implementation appears to be picky in some environments; to avoid
		// edge cases with certain characters, we generate a strictly alphanumeric
		// verifier (still valid per RFC as a subset of the allowed charset).
		const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		var bytes = RandomNumberGenerator.GetBytes(64); // 64 chars is safely within 43-128
		var sb = new StringBuilder(64);
		for (var i = 0; i < bytes.Length; i++)
			sb.Append(chars[bytes[i] % chars.Length]);
		return sb.ToString();
    }

    private static string GenerateCodeChallenge(string verifier)
    {
        using var sha = SHA256.Create();
        // TikTok Login Kit for Desktop requires HEX encoding of SHA256(code_verifier)
        // for the code_challenge (not Base64Url). See TikTok Desktop Login Kit docs.
        var hash = sha.ComputeHash(Encoding.UTF8.GetBytes(verifier));
        var sb = new StringBuilder(hash.Length * 2);
        foreach (var b in hash)
            sb.Append(b.ToString("x2"));
        return sb.ToString();
    }


}
