using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public sealed class OllamaSmartLiteService
{
    private readonly HttpClient _http;
    private readonly JsonlLogger _log;

    public OllamaSmartLiteService(HttpClient http, JsonlLogger log)
    {
        _http = http;
        _log = log;
    }

    public sealed record SmartLiteResult(string Title, string Caption, List<string> Hashtags);

    public async Task<SmartLiteResult> GenerateAsync(
        AppSettings settings,
        string videoPath,
        CancellationToken ct,
        string? variationPreset = null,
        IReadOnlyList<string>? avoidTitles = null)
    {
        // 1) Extract frames
        var tmp = Path.Combine(Path.GetTempPath(), "ShortUploader", "frames", Guid.NewGuid().ToString("N"));
        List<string> frames;
        try
        {
            frames = await FrameExtractor.ExtractJpegFramesAsync(videoPath, tmp, settings, settings.SmartLiteFramesPerVideo, ct);
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException($"SmartLite: Frame extraction failed: {ex.Message}", ex);
        }

        // 2) Build prompt
        var prompt = BuildPrompt(settings, variationPreset, avoidTitles);

        // 3) Load images -> base64
        var imagesB64 = new List<string>();
        foreach (var f in frames)
        {
            ct.ThrowIfCancellationRequested();
            var bytes = await File.ReadAllBytesAsync(f, ct);
            imagesB64.Add(Convert.ToBase64String(bytes));
        }

        // 4) Call Ollama /api/chat
        var baseUrl = (settings.SmartLiteOllamaBaseUrl ?? "http://localhost:11434").TrimEnd('/');
        var url = $"{baseUrl}/api/chat";

        var model = string.IsNullOrWhiteSpace(settings.SmartLiteModel) ? "llama3.2-vision" : settings.SmartLiteModel.Trim();

        async Task<string> SendAsync(List<string> imgs)
        {
            var payload = new
            {
                model,
                stream = false,
                messages = new object[]
                {
                    new { role = "system", content = "You are a helpful assistant for generating short social video titles and hashtags." },
                    new { role = "user", content = prompt, images = imgs }
                }
            };

            using var req = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = new StringContent(JsonSerializer.Serialize(payload), Encoding.UTF8, "application/json")
            };

            HttpResponseMessage resp;
            try
            {
                resp = await _http.SendAsync(req, ct);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException($"SmartLite: Ollama request failed: {ex.Message}", ex);
            }

            var body = await resp.Content.ReadAsStringAsync(ct);
            if (!resp.IsSuccessStatusCode)
                throw new InvalidOperationException($"SmartLite: Ollama HTTP {(int)resp.StatusCode}: {body}");

            return body;
        }

        string body;
        try
        {
            body = await SendAsync(imagesB64);
        }
        catch (InvalidOperationException ex) when (
            ex.Message.Contains("only supports one image", StringComparison.OrdinalIgnoreCase) && imagesB64.Count > 1)
        {
            // Some Ollama vision models accept only a single image.
            // Fallback: retry with the first frame only.
            _log.Log("smartlite_ollama_single_image_fallback", new { model, framesRequested = imagesB64.Count });
            body = await SendAsync(new List<string> { imagesB64[0] });
        }

        // 5) Extract model output
        var content = ExtractChatContent(body);
        if (string.IsNullOrWhiteSpace(content))
            throw new InvalidOperationException("SmartLite: Ollama response contained no content.");

        // 6) Parse JSON from content (strict). If that fails, fall back to a tolerant parser.
        try
        {
            var parsed = TryParseStrictJson(settings, content);
            if (parsed is not null)
                return parsed;

            var loose = ParseLoose(settings, content);
            _log.Log("smartlite_loose_parse_used", new { model, rawPreview = TruncateForLog(content, 300) });
            return loose;
        }
        finally
        {
            try { Directory.Delete(tmp, true); } catch { /* ignore */ }
        }
    }

    private SmartLiteResult? TryParseStrictJson(AppSettings settings, string content)
    {
        var json = ExtractFirstJsonObject(content);
        if (string.IsNullOrWhiteSpace(json))
            return null;

        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            var title = root.TryGetProperty("title", out var t) ? (t.GetString() ?? "") : "";
            var caption = root.TryGetProperty("caption", out var c) ? (c.GetString() ?? "") : "";
            var tags = new List<string>();
            if (root.TryGetProperty("hashtags", out var h) && h.ValueKind == JsonValueKind.Array)
            {
                foreach (var el in h.EnumerateArray())
                {
                    var s = el.GetString();
                    if (!string.IsNullOrWhiteSpace(s)) tags.Add(NormalizeHashtag(s!));
                }
            }

            title = (title ?? "").Trim();
            caption = (caption ?? "").Trim();
            tags = CleanTags(settings, tags);

            if (string.IsNullOrWhiteSpace(title))
                return null;

            return new SmartLiteResult(title, caption, tags);
        }
        catch (Exception ex)
        {
            _log.Log("smartlite_strict_json_parse_failed", new { error = ex.Message, rawPreview = TruncateForLog(content, 300) });
            return null;
        }
    }

    private static SmartLiteResult ParseLoose(AppSettings settings, string content)
    {
        // 1) Hashtags: pull any #tags from the text
        var tagMatches = Regex.Matches(content, @"#([\p{L}\p{N}_]+)");
        var tags = new List<string>();
        foreach (Match m in tagMatches)
        {
            var raw = m.Value;
            if (!string.IsNullOrWhiteSpace(raw))
                tags.Add(NormalizeHashtag(raw));
        }

        // 2) Try to extract a title field even if JSON is truncated
        //    Example: { "title": "Some title...
        var title = "";
        var mTitle = Regex.Match(content, "\\\"title\\\"\\s*:\\s*\\\"([^\\\"\\r\\n]{3,120})");
        if (mTitle.Success)
        {
            title = mTitle.Groups[1].Value.Trim();
        }
        else
        {
            // Fallback: first non-empty line, stripped of braces/quotes
            var line = content.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None)
                              .Select(l => l.Trim())
                              .FirstOrDefault(l => !string.IsNullOrWhiteSpace(l));
            if (!string.IsNullOrWhiteSpace(line))
            {
                title = line.Trim().Trim('{', '}', '"', '\'', ' ');
                // Remove leading labels like "Title:" if present
                title = Regex.Replace(title, @"^(title\s*:\s*)", "", RegexOptions.IgnoreCase).Trim();
            }
        }

        // 3) Caption: optional; try to extract "caption" or otherwise blank
        var caption = "";
        var mCaption = Regex.Match(content, "\\\"caption\\\"\\s*:\\s*\\\"([^\\\"\\r\\n]{0,200})");
        if (mCaption.Success)
            caption = mCaption.Groups[1].Value.Trim();

        // 4) If no tags found, derive some simple tags from the title words
        tags = CleanTags(settings, tags);
        if (tags.Count == 0)
        {
            var derived = DeriveTagsFromTitle(title);
            tags = CleanTags(settings, derived);
        }

        // 5) Ensure we always return something usable
        if (string.IsNullOrWhiteSpace(title))
            title = "Short Video";

        return new SmartLiteResult(title, caption, tags);
    }

    private static List<string> DeriveTagsFromTitle(string title)
    {
        var tags = new List<string>();
        if (string.IsNullOrWhiteSpace(title)) return tags;

        foreach (var w in Regex.Split(title.ToLowerInvariant(), @"[^\p{L}\p{N}]+"))
        {
            var s = w.Trim();
            if (s.Length < 3) continue;
            tags.Add("#" + s);
            if (tags.Count >= 12) break;
        }
        return tags;
    }

    private static List<string> CleanTags(AppSettings settings, List<string> tags)
    {
        var max = Math.Max(1, settings.SmartLiteMaxHashtags);
        return tags
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(NormalizeHashtag)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .Take(max)
            .ToList();
    }

    private static string TruncateForLog(string s, int max)
    {
        if (string.IsNullOrEmpty(s)) return "";
        s = s.Replace("\r", " ").Replace("\n", " ");
        return s.Length <= max ? s : s.Substring(0, max) + "…";
    }

    private static string BuildPrompt(AppSettings settings, string? variationPreset, IReadOnlyList<string>? avoidTitles)
    {
        var lang = (settings.SmartLiteLanguage ?? "de").ToLowerInvariant();
        var style = (settings.SmartLiteStyle ?? "clean").ToLowerInvariant();
        var maxTags = Math.Max(5, Math.Min(settings.SmartLiteMaxHashtags, 20));

        var langInstr = lang switch
        {
            "en" => "Write in English.",
            "mixed" => "Write title in English, but hashtags can be mixed English/German if appropriate.",
            _ => "Write in German."
        };

        var styleInstr = style switch
        {
            "hype" => "Style: high-energy, short, punchy.",
            "cinematic" => "Style: cinematic, descriptive but concise.",
            _ => "Style: clean, straightforward."
        };

        var presetInstr = variationPreset switch
        {
            "very_short" => "Title pattern: 2–3 words. No punctuation. Make it unique.",
            "short" => "Title pattern: 3–5 words. Make it unique.",
            "medium" => "Title pattern: 5–7 words. Include a concrete scene detail (e.g., tunnel, rain, neon, reflections).",
            "hook" => "Title pattern: hook style (natural, not clickbait). 5–9 words. Avoid repeating common phrases.",
            "cinematic" => "Title pattern: cinematic vibe. 5–9 words. Include one unique detail.",
            "action" => "Title pattern: action-focused. 4–8 words. Use dynamic verbs.",
            _ => "Title pattern: vary length between 2 and 9 words across different videos. Be creative but accurate."
        };

        var avoidInstr = "";
        if (avoidTitles is not null && avoidTitles.Count > 0)
        {
            // Keep the avoid-list short to reduce token usage.
            var last = avoidTitles.TakeLast(25).ToArray();
            avoidInstr = "\nAvoid reusing or closely paraphrasing any of these existing titles (be noticeably different):\n- "
                         + string.Join("\n- ", last);
        }

        return $@"Analyze the provided frames from a short video.
Goal: generate a strong, relevant title and a set of hashtags for TikTok/Shorts.

Rules:
- Return ONLY valid JSON.
- JSON schema: {{ ""title"": string, ""caption"": string, ""hashtags"": string[] }}
- Provide {maxTags} hashtags (8–15 is typical). Always start hashtags with '#'.
- Avoid spammy or misleading tags. Prefer a mix of broad and niche.
- Do not include watermarks or promotional branding.
- Do NOT repeat generic phrases across multiple videos. Prefer novel wording and unique details.

{presetInstr}{avoidInstr}

{langInstr}
{styleInstr}
";
    }

    private static string ExtractChatContent(string ollamaJson)
    {
        try
        {
            using var doc = JsonDocument.Parse(ollamaJson);
            if (doc.RootElement.TryGetProperty("message", out var msg) && msg.TryGetProperty("content", out var c))
                return c.GetString() ?? "";
        }
        catch
        {
            // ignore
        }
        return "";
    }

    private static string ExtractFirstJsonObject(string text)
    {
        // Find the first '{' and match braces.
        var start = text.IndexOf('{');
        if (start < 0) return "";
        int depth = 0;
        for (int i = start; i < text.Length; i++)
        {
            if (text[i] == '{') depth++;
            else if (text[i] == '}')
            {
                depth--;
                if (depth == 0)
                    return text.Substring(start, i - start + 1);
            }
        }
        return "";
    }

    private static string NormalizeHashtag(string tag)
    {
        tag = tag.Trim();
        if (!tag.StartsWith('#')) tag = "#" + tag;
        // remove spaces
        tag = tag.Replace(" ", "");
        return tag;
    }
}
