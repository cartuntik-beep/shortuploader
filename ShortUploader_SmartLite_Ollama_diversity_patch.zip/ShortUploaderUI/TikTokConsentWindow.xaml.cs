using System.Windows;

namespace ShortUploaderUI;

public partial class TikTokConsentWindow : Window
{
    public TikTokConsentWindow(string declarationText, string privacyText, string interactionsText, string commercialText, string videoCountText)
    {
        InitializeComponent();

        DataContext = new
        {
            DeclarationText = declarationText,
            PrivacyText = privacyText,
            InteractionsText = interactionsText,
            CommercialText = commercialText,
            VideoCountText = videoCountText
        };

        // UX: require explicit checkbox consent before enabling the OK button.
        if (OkButton != null)
            OkButton.IsEnabled = false;

        if (ConsentCheck != null)
        {
            ConsentCheck.Checked += (_, __) =>
            {
                if (OkButton != null) OkButton.IsEnabled = true;
            };

            ConsentCheck.Unchecked += (_, __) =>
            {
                if (OkButton != null) OkButton.IsEnabled = false;
            };
        }
    }

    private void Ok_Click(object sender, RoutedEventArgs e)
    {
        // Only proceed when consent is checked.
        if (ConsentCheck != null && ConsentCheck.IsChecked == true)
        {
            DialogResult = true;
            Close();
            return;
        }

        System.Windows.MessageBox.Show(
            "Please confirm the declaration before continuing.",
            "Consent required",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
        Close();
    }
}
