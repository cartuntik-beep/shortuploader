using ShortUploaderUI.Models;
using ShortUploaderUI.Services;
using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace ShortUploaderUI;

public partial class TikTokPostWindow : Window, INotifyPropertyChanged
{
    private readonly Func<AppSettings> _settingsProvider;
    private readonly Action _saveSettings;
    private readonly Action<string> _globalLog;

    public event PropertyChangedEventHandler? PropertyChanged;

    private string _creatorDisplay = "(not loaded)";
    public string CreatorDisplay { get => _creatorDisplay; set { _creatorDisplay = value; OnPropertyChanged(); } }

    private TikTokCreatorInfo? _creatorInfo;
    public System.Collections.ObjectModel.ObservableCollection<string> PrivacyOptions { get; } = new();

    private string _selectedPrivacyOption = "";
    public string SelectedPrivacyOption
    {
        get => _selectedPrivacyOption;
        set { _selectedPrivacyOption = value; OnPropertyChanged(); RecomputeCanSave(); UpdateCommercialConstraints(); }
    }

    private string _captionTemplate = "";
    public string CaptionTemplate { get => _captionTemplate; set { _captionTemplate = value; OnPropertyChanged(); RecomputeCanSave(); } }

    // Interaction: must be manually enabled, none checked by default
    private bool _allowComment;
    public bool AllowComment { get => _allowComment; set { _allowComment = value; OnPropertyChanged(); } }
    private bool _allowDuet;
    public bool AllowDuet { get => _allowDuet; set { _allowDuet = value; OnPropertyChanged(); } }
    private bool _allowStitch;
    public bool AllowStitch { get => _allowStitch; set { _allowStitch = value; OnPropertyChanged(); } }

    public bool AllowCommentEnabled { get; private set; } = true;
    public bool AllowDuetEnabled { get; private set; } = true;
    public bool AllowStitchEnabled { get; private set; } = true;

    // Commercial disclosure
    private bool _commercialToggle;
    public bool CommercialToggle { get => _commercialToggle; set { _commercialToggle = value; OnPropertyChanged(); RecomputeCanSave(); UpdateCommercialConstraints(); UpdateDeclarationText(); } }
    private bool _commercialYourBrand;
    public bool CommercialYourBrand { get => _commercialYourBrand; set { _commercialYourBrand = value; OnPropertyChanged(); RecomputeCanSave(); UpdateDeclarationText(); } }
    private bool _commercialBrandedContent;
    public bool CommercialBrandedContent { get => _commercialBrandedContent; set { _commercialBrandedContent = value; OnPropertyChanged(); RecomputeCanSave(); UpdateCommercialConstraints(); UpdateDeclarationText(); } }
    public bool CommercialBrandedContentEnabled { get; private set; } = true;

    // Guideline Point 4: Consent declaration text (depends on commercial selections)
    private string _declarationText = "By posting, you agree to TikTok's Music Usage Confirmation.";
    public string DeclarationText { get => _declarationText; set { _declarationText = value; OnPropertyChanged(); } }

    private bool _canSave;
    public bool CanSave { get => _canSave; set { _canSave = value; OnPropertyChanged(); } }

    private string _statusLog = "";
    public string StatusLog { get => _statusLog; set { _statusLog = value; OnPropertyChanged(); } }

    public TikTokPostWindow(Func<AppSettings> settingsProvider, Action saveSettings, Action<string> globalLog)
    {
        InitializeComponent();
        DataContext = this;
        _settingsProvider = settingsProvider;
        _saveSettings = saveSettings;
        _globalLog = globalLog;

        // Load saved settings into the UI (except for privacy, which must have no default selection).
        var s = _settingsProvider();
        CaptionTemplate = s.TikTokCaptionTemplate ?? "{stem}";
        AllowComment = !s.TikTokDisableComment;
        AllowDuet = !s.TikTokDisableDuet;
        AllowStitch = !s.TikTokDisableStitch;

        CommercialToggle = s.TikTokCommercialToggle;
        CommercialYourBrand = s.TikTokCommercialYourBrand;
        CommercialBrandedContent = s.TikTokCommercialBrandedContent;

        _selectedPrivacyOption = ""; // no default
        // Allow saving non-privacy settings immediately. Privacy selection is required only for publishing,
        // not for persisting other settings.
        RecomputeCanSave();

        UpdateDeclarationText();

        _ = LoadCreatorInfoAsync();
    }

    private void Log(string msg)
    {
        var ts = DateTime.Now.ToString("HH:mm:ss");
        StatusLog += $"[{ts}] {msg}\n";
        _globalLog(msg);
    }

    private async Task LoadCreatorInfoAsync()
    {
        try
        {
            var settings = _settingsProvider();
            var tokenStore = new TikTokTokenStore();
            var oauth = new TikTokOAuthClient();
            var tokenManager = new TikTokTokenManager(tokenStore, oauth);
            var token = await tokenManager.EnsureValidAccessTokenAsync(settings, Log, CancellationToken.None);

            var api = new TikTokServiceWrapper(token);
            var info = await api.QueryCreatorInfoAsync(CancellationToken.None);
            _creatorInfo = info;

            CreatorDisplay = !string.IsNullOrWhiteSpace(info.Username)
                ? $"{info.Nickname} (@{info.Username})"
                : (!string.IsNullOrWhiteSpace(info.Nickname) ? info.Nickname : "(unknown creator)");

            PrivacyOptions.Clear();
            if (info.PrivacyLevelOptions.Count > 0)
            {
                foreach (var opt in info.PrivacyLevelOptions.Where(o => !string.IsNullOrWhiteSpace(o)))
                    PrivacyOptions.Add(opt);
            }
            else
            {
                PrivacyOptions.Add("SELF_ONLY");
                PrivacyOptions.Add("PUBLIC_TO_EVERYONE");
            }

            // Force no default selection.
            SelectedPrivacyOption = "";

            // Interaction enablement based on creator settings
            AllowCommentEnabled = !info.CommentDisabledInApp;
            AllowDuetEnabled = !info.DuetDisabledInApp;
            AllowStitchEnabled = !info.StitchDisabledInApp;

            if (!AllowCommentEnabled) AllowComment = false;
            if (!AllowDuetEnabled) AllowDuet = false;
            if (!AllowStitchEnabled) AllowStitch = false;

            OnPropertyChanged(nameof(AllowCommentEnabled));
            OnPropertyChanged(nameof(AllowDuetEnabled));
            OnPropertyChanged(nameof(AllowStitchEnabled));
            OnPropertyChanged(nameof(PrivacyOptions));

            if (!info.CanPost)
            {
                Log("Creator is currently not allowed to post. " + (info.CanPostReason ?? ""));
            }

            // Show the currently saved privacy in the log (we do not auto-select it).
            var savedPrivacy = _settingsProvider().TikTokPrivacyLevel ?? "";
            if (!string.IsNullOrWhiteSpace(savedPrivacy))
                Log($"Saved privacy setting: {savedPrivacy} (no default selection in UI)");
        }
        catch (Exception ex)
        {
            CreatorDisplay = "(failed to load creator info)";
            Log("Creator info error: " + ex.Message);

            // If creator_info/query fails (network, auth, API change), do not leave the privacy dropdown empty.
            // TikTok review expects a visible privacy selector; we fall back to safe defaults.
            PrivacyOptions.Clear();
            PrivacyOptions.Add("SELF_ONLY");
            PrivacyOptions.Add("PUBLIC_TO_EVERYONE");

            // Keep 'no default' behavior.
            SelectedPrivacyOption = "";

            OnPropertyChanged(nameof(PrivacyOptions));
        }
        finally
        {
            RecomputeCanSave();
        }
    }

    private void UpdateCommercialConstraints()
    {
        // Branded content cannot be private (SELF_ONLY). If SELF_ONLY is selected, disable branded-content.
        var privacy = SelectedPrivacyOption ?? "";
        if (string.Equals(privacy, "SELF_ONLY", StringComparison.OrdinalIgnoreCase))
        {
            CommercialBrandedContentEnabled = false;
            if (CommercialBrandedContent) CommercialBrandedContent = false;
        }
        else
        {
            CommercialBrandedContentEnabled = true;
        }
        OnPropertyChanged(nameof(CommercialBrandedContentEnabled));
        RecomputeCanSave();
        UpdateDeclarationText();
    }

    private void UpdateDeclarationText()
    {
        // UX Guideline Point 4: Declaration depends on commercial content settings
        // - Default / Your Brand only: Music Usage Confirmation
        // - Branded Content (alone or together): Branded Content Policy + Music Usage Confirmation

        if (!CommercialToggle)
        {
            DeclarationText = "By posting, you agree to TikTok's Music Usage Confirmation.";
            return;
        }

        var yourBrand = CommercialYourBrand;
        var branded = CommercialBrandedContent;

        if (branded)
        {
            DeclarationText = "By posting, you agree to TikTok's Branded Content Policy and Music Usage Confirmation.";
            return;
        }

        // Commercial toggle on, but only your brand selected (or none yet)
        DeclarationText = "By posting, you agree to TikTok's Music Usage Confirmation.";
    }

    private void RefreshCreatorInfo_Click(object sender, RoutedEventArgs e)
    {
        _ = LoadCreatorInfoAsync();
    }

    private void RecomputeCanSave()
    {
        var commercialOk = true;
        if (CommercialToggle)
        {
            commercialOk = CommercialYourBrand || CommercialBrandedContent;
            if (CommercialBrandedContent && string.Equals(SelectedPrivacyOption, "SELF_ONLY", StringComparison.OrdinalIgnoreCase))
                commercialOk = false;
        }

        // Saving settings should not be blocked just because privacy wasn't selected on this page.
        // If privacy remains empty, we keep the previously saved privacy value.
        CanSave = commercialOk;
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            RecomputeCanSave();
            if (!CanSave)
            {
                System.Windows.MessageBox.Show(
                    "Wenn Commercial Content aktiv ist, muss mindestens eine Option (Your brand oder Branded content) gewählt sein.\n\nHinweis: Privacy hat absichtlich keinen Default (TikTok UX). Du kannst andere Einstellungen speichern, auch wenn du hier keine Privacy auswählst.",
                    "Fehlende Angaben",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
                return;
            }

            var s = _settingsProvider();
            s.TikTokCaptionTemplate = CaptionTemplate ?? "{stem}";

            // Privacy has no default selection (TikTok UX requirement). Allow saving other settings without changing privacy.
            if (!string.IsNullOrWhiteSpace(SelectedPrivacyOption))
                s.TikTokPrivacyLevel = SelectedPrivacyOption;

            // Save as disable_* flags (main uploader uses disable flags)
            s.TikTokDisableComment = !AllowComment;
            s.TikTokDisableDuet = !AllowDuet;
            s.TikTokDisableStitch = !AllowStitch;

            s.TikTokCommercialToggle = CommercialToggle;
            s.TikTokCommercialYourBrand = CommercialYourBrand;
            s.TikTokCommercialBrandedContent = CommercialBrandedContent;

            _saveSettings();
            Log("TikTok settings saved.");
            DialogResult = true;
            Close();
        }
        catch (Exception ex)
        {
            Log("Save failed: " + ex.Message);
            System.Windows.MessageBox.Show(ex.Message, "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void OnPropertyChanged([CallerMemberName] string? name = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
