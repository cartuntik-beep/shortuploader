using Microsoft.Win32;
using ShortUploaderUI.Models;
using ShortUploaderUI.Services;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Windows;
using Forms = System.Windows.Forms;

namespace ShortUploaderUI;

public partial class MainWindow : Window, INotifyPropertyChanged
{
    private readonly SettingsStore _settingsStore;
    private readonly UploaderOrchestrator _orchestrator;

    public AppSettings Settings { get; private set; }

    private string _videoFolder = "";
    public string VideoFolder
    {
        get => _videoFolder;
        set { _videoFolder = value; OnPropertyChanged(); }
    }

    public string TikTokTokenStatus { get => _tikTokTokenStatus; set { _tikTokTokenStatus = value; OnPropertyChanged(); } }
    private string _tikTokTokenStatus = "(nicht eingeloggt)";

    public ObservableCollection<QueueItem> Queue { get; } = new();

    private string _statusText = "Bereit.";
    public string StatusText
    {
        get => _statusText;
        set { _statusText = value; OnPropertyChanged(); }
    }

    private string _logText = "";
    public string LogText
    {
        get => _logText;
        set { _logText = value; OnPropertyChanged(); }
    }

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;

        _settingsStore = new SettingsStore("app_settings.json");
        Settings = _settingsStore.LoadOrCreateDefault();
        VideoFolder = Settings.VideoFolder ?? "";

        // Populate sensitive UI fields after settings are loaded.
        TikTokClientSecretBox.Password = Settings.TikTokClientSecret ?? "";
        RefreshTikTokTokenStatus();


        _orchestrator = new UploaderOrchestrator(
            settingsProvider: () => Settings,
            onStatus: AppendStatus,
            onQueueUpdate: UpdateQueueRow
        );

        AppendStatus("App geladen.");
    }

    private void AppendStatus(string message)
    {
        Dispatcher.Invoke(() =>
        {
            StatusText = message;
            var ts = DateTime.Now.ToString("HH:mm:ss");
            LogText += $"[{ts}] {message}\n";
        });
    }

    private void UpdateQueueRow(int index, QueueItem updated)
    {
        Dispatcher.Invoke(() =>
        {
            if (index >= 0 && index < Queue.Count)
            {
                Queue[index] = updated;
            }
        });
    }

    private void PickFolder_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Forms.FolderBrowserDialog();
        dlg.Description = "Ordner mit Videos auswählen";
        dlg.UseDescriptionForTitle = true;

        var res = dlg.ShowDialog();
        if (res == Forms.DialogResult.OK && !string.IsNullOrWhiteSpace(dlg.SelectedPath))
        {
            VideoFolder = dlg.SelectedPath;
            Settings.VideoFolder = dlg.SelectedPath;
            AppendStatus("Ordner gewählt.");
        }
    }

    private void Scan_Click(object sender, RoutedEventArgs e)
    {
        Queue.Clear();

        if (string.IsNullOrWhiteSpace(VideoFolder) || !Directory.Exists(VideoFolder))
        {
            System.Windows.MessageBox.Show("Bitte einen gültigen Video-Ordner auswählen.", "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var videos = FileScanner.ListVideos(VideoFolder, Settings.FileExtensions);
        foreach (var p in videos)
        {
            Queue.Add(new QueueItem
            {
                FullPath = p,
                FileName = Path.GetFileName(p),
                Status = "READY",
                YouTubeResult = "",
                TikTokResult = ""
            });
        }

        ApplyPlanningToQueue();

        AppendStatus($"{Queue.Count} Video(s) in die Queue geladen.");
    }

    private async void Start_Click(object sender, RoutedEventArgs e)
    {
        if (Queue.Count == 0)
        {
            Scan_Click(sender, e);
            if (Queue.Count == 0) return;
        }

        try
        {
            SaveSettingsInternal();
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show(ex.Message, "Einstellungen ungültig", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }


// Ensure planned slots are assigned before starting.
if (Settings.PlanningEnabled || Settings.UsePlatformScheduling)
{
    ApplyPlanningToQueue();

    if (Settings.UsePlatformScheduling)
    {
        var missing = Queue.Where(q => string.IsNullOrWhiteSpace(q.PublishAtLocal)).Select(q => q.FileName).ToList();
        if (missing.Count > 0)
        {
            var msg = "Plattform-Planung ist aktiv, aber für folgende Dateien ist keine geplante Zeit gesetzt:\n"
                      + string.Join("\n", missing.Take(10))
                      + (missing.Count > 10 ? "\n…" : "")
                      + "\n\nBitte im Tab \"Planung\" Startdatum/Uhrzeiten setzen und \"Plan berechnen\" drücken.";
            AppendStatus("Fehler: " + msg.Replace("\n", " | "));
            System.Windows.MessageBox.Show(msg, "Planung", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
    }
}
        AppendStatus("Start…");
        try
        {
            await _orchestrator.RunAsync(Queue.ToList());
        }
        catch (Exception ex)
        {
            AppendStatus("Run abgebrochen: " + ex.Message);
            System.Windows.MessageBox.Show(ex.Message, "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Stop_Click(object sender, RoutedEventArgs e)
    {
        _orchestrator.RequestStop();
        AppendStatus("Stop angefordert…");
    }

    private void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveSettingsInternal();
            System.Windows.MessageBox.Show("Gespeichert.", "OK", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            System.Windows.MessageBox.Show(ex.Message, "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SaveSettingsInternal()
    {
        Settings.VideoFolder = VideoFolder;

        _settingsStore.Save(Settings);
    }


private void Plan_Click(object sender, RoutedEventArgs e)
{
    try
    {
        ApplyPlanningToQueue();
        AppendStatus("Plan berechnet.");
    }
    catch (Exception ex)
    {
        AppendStatus("Plan Fehler: " + ex.Message);
        System.Windows.MessageBox.Show(ex.Message, "Planung", MessageBoxButton.OK, MessageBoxImage.Error);
    }
}

private void PlanClear_Click(object sender, RoutedEventArgs e)
{
    foreach (var item in Queue)
    {
        item.PublishAtLocal = "";
    }
    for (int i = 0; i < Queue.Count; i++) Queue[i] = Queue[i];
    AppendStatus("Plan geleert.");
}

private void ApplyPlanningToQueue()
{
    if (!Settings.PlanningEnabled) return;
    if (Queue.Count == 0) return;

    var startDateText = (Settings.PlanningStartDate ?? "").Trim();
    if (string.IsNullOrWhiteSpace(startDateText))
        throw new Exception("Bitte ein Startdatum setzen (YYYY-MM-DD).");

    var startDate = DateTime.ParseExact(startDateText, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
    var days = Math.Max(1, Settings.PlanningDays);
    var perDay = Math.Max(1, Settings.PlanningVideosPerDay);

    var times = (Settings.PlanningTimesCsv ?? "")
        .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
        .Select(t => DateTime.ParseExact(t, "HH:mm", System.Globalization.CultureInfo.InvariantCulture).TimeOfDay)
        .ToList();

    if (times.Count == 0)
        throw new Exception("Bitte mindestens eine Uhrzeit angeben (z.B. 10:00,18:00).");

    int idx = 0;
    for (int d = 0; idx < Queue.Count; d++)
    {
        var date = startDate.Date.AddDays(d);
        for (int k = 0; k < perDay && idx < Queue.Count; k++)
        {
            var t = times[k % times.Count];
            var dt = date.Add(t);
            Queue[idx].PublishAtLocal = dt.ToString("yyyy-MM-dd HH:mm");
            idx++;
        }
        // stop after horizon only if user set finite; continue scheduling anyway to cover all queued items
        if (d + 1 >= days && idx >= Queue.Count) break;
    }

    for (int i = 0; i < Queue.Count; i++) Queue[i] = Queue[i];
}

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

    private void TikTokClientSecretBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        Settings.TikTokClientSecret = TikTokClientSecretBox.Password;
    }

    private void RefreshTikTokTokenStatus()
    {
        try
        {
            var store = new TikTokTokenStore();
            var b = store.Load();
            if (b == null)
            {
                TikTokTokenStatus = "(nicht eingeloggt)";
                return;
            }

            var expLocal = b.AccessTokenExpiresAtUtc.ToLocalTime().ToString("yyyy-MM-dd HH:mm");
            TikTokTokenStatus = b.IsAccessTokenValid() ? $"OK bis {expLocal}" : $"abgelaufen ({expLocal})";
        }
        catch
        {
            TikTokTokenStatus = "(unbekannt)";
        }
    }

    private async void TikTokLogin_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var store = new TikTokTokenStore();
            var oauth = new TikTokOAuthClient();

            AppendStatus("TikTok Login gestartet …");

            var bundle = await oauth.LoginDesktopAsync(
                Settings.TikTokClientKey,
                Settings.TikTokClientSecret,
                Settings.TikTokScopesCsv,
                Settings.TikTokRedirectHost,
                Settings.TikTokRedirectPort,
                Settings.TikTokRedirectPath,
                AppendStatus,
                CancellationToken.None);

            store.Save(bundle);
            RefreshTikTokTokenStatus();
            AppendStatus("TikTok Login erfolgreich.");
        }
        catch (Exception ex)
        {
            AppendStatus("TikTok Login FEHLER: " + ex.Message);
            System.Windows.MessageBox.Show(ex.Message, "TikTok Login fehlgeschlagen", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void TikTokLogout_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var store = new TikTokTokenStore();
            store.Clear();
            RefreshTikTokTokenStatus();
            AppendStatus("TikTok Logout: Token gelöscht.");
        }
        catch (Exception ex)
        {
            AppendStatus("TikTok Logout FEHLER: " + ex.Message);
        }
    }

}
