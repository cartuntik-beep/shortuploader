using System.Security.Cryptography;
using System.Text.Json;
using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public class TikTokTokenStore
{
    private readonly string _path;

    public TikTokTokenStore(string? baseDir = null)
    {
        var dir = baseDir ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "ShortUploader");
        Directory.CreateDirectory(dir);
        _path = Path.Combine(dir, "tiktok_tokens.bin");
    }

    public void Clear()
    {
        if (File.Exists(_path)) File.Delete(_path);
    }

    public void Save(TikTokTokenBundle bundle)
    {
        var json = JsonSerializer.SerializeToUtf8Bytes(bundle, new JsonSerializerOptions { WriteIndented = false });
        var enc = ProtectedData.Protect(json, null, DataProtectionScope.CurrentUser);
        File.WriteAllBytes(_path, enc);
    }

    public TikTokTokenBundle? Load()
    {
        if (!File.Exists(_path)) return null;
        var enc = File.ReadAllBytes(_path);
        var dec = ProtectedData.Unprotect(enc, null, DataProtectionScope.CurrentUser);
        return JsonSerializer.Deserialize<TikTokTokenBundle>(dec);
    }
}
