namespace ShortUploaderUI.Services;

public static class TextTemplate
{
    public static string Apply(string template, string fullPath)
    {
        var fileName = Path.GetFileName(fullPath);
        var stem = Path.GetFileNameWithoutExtension(fullPath);
        return (template ?? "")
            .Replace("{stem}", stem)
            .Replace("{filename}", fileName);
    }
}

public static class Backoff
{
    private static readonly Random Rng = new();

    public static TimeSpan Compute(int baseSeconds, int maxSeconds, int attemptIndex)
    {
        // attemptIndex starts at 1
        var raw = Math.Min(maxSeconds, baseSeconds * (int)Math.Pow(2, attemptIndex - 1));
        var jitter = 0.7 + Rng.NextDouble() * 0.6;
        return TimeSpan.FromSeconds(raw * jitter);
    }
}

public static class SafeMove
{
    public static string MoveTo(string src, string dstDir)
    {
        Directory.CreateDirectory(dstDir);
        var baseName = Path.GetFileName(src);
        var stem = Path.GetFileNameWithoutExtension(src);
        var ext = Path.GetExtension(src);

        var dst = Path.Combine(dstDir, baseName);
        if (!File.Exists(dst))
        {
            File.Move(src, dst);
            return dst;
        }

        for (var i = 1; i < 1000; i++)
        {
            var cand = Path.Combine(dstDir, $"{stem}__{i}{ext}");
            if (!File.Exists(cand))
            {
                File.Move(src, cand);
                return cand;
            }
        }

        throw new IOException("Name collision could not be resolved.");
    }
}
