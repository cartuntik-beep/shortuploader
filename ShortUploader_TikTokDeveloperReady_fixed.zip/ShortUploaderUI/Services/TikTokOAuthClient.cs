using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public class TikTokOAuthClient
{
    private const string AuthorizeEndpoint = "https://www.tiktok.com/v2/auth/authorize/";
    private const string TokenEndpoint = "https://open.tiktokapis.com/v2/oauth/token/";

    public async Task<TikTokTokenBundle> LoginDesktopAsync(
        string clientKey,
        string clientSecret,
        string scopesCsv,
        string redirectHost,
        int redirectPort,
        string redirectPath,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(clientKey)) throw new Exception("TikTok Client Key fehlt.");
        if (string.IsNullOrWhiteSpace(clientSecret)) throw new Exception("TikTok Client Secret fehlt.");
        if (string.IsNullOrWhiteSpace(scopesCsv)) throw new Exception("TikTok Scopes fehlen.");

        var scopes = scopesCsv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (scopes.Length == 0) throw new Exception("TikTok Scopes fehlen.");

        var state = Guid.NewGuid().ToString("N");
        var verifier = GenerateCodeVerifier();
        var challenge = GenerateCodeChallenge(verifier);

        var port = redirectPort == 0 ? GetFreePort() : redirectPort;
        var path = string.IsNullOrWhiteSpace(redirectPath) ? "/callback/" : redirectPath;
        if (!path.EndsWith('/')) path += "/";

        var redirectUri = $"http://{redirectHost}:{port}{path}";
        onStatus?.Invoke($"TikTok OAuth Redirect: {redirectUri}");

        using var listener = new HttpListener();
        listener.Prefixes.Add(redirectUri);
        listener.Start();

        var authorizeUrl = BuildAuthorizeUrl(clientKey, redirectUri, scopes, state, challenge);
        onStatus?.Invoke("Öffne TikTok Login im Browser …");

        Process.Start(new ProcessStartInfo
        {
            FileName = authorizeUrl,
            UseShellExecute = true
        });

        // Wait for callback
        var ctxTask = listener.GetContextAsync();
        using (ct.Register(() => { try { listener.Stop(); } catch { } }))
        {
            var ctx = await ctxTask;
            var qs = ctx.Request.QueryString;

            var returnedState = qs["state"];
            var code = qs["code"];
            var error = qs["error"];

            var html = "<html><body><h3>Login erfolgreich.</h3><p>Du kannst dieses Fenster schließen.</p></body></html>";
            if (!string.IsNullOrWhiteSpace(error) || string.IsNullOrWhiteSpace(code))
            {
                html = "<html><body><h3>Login fehlgeschlagen.</h3><p>Bitte zur App zurückkehren.</p></body></html>";
            }

            var bytes = Encoding.UTF8.GetBytes(html);
            ctx.Response.ContentType = "text/html; charset=utf-8";
            ctx.Response.OutputStream.Write(bytes, 0, bytes.Length);
            ctx.Response.Close();

            if (returnedState != state) throw new Exception("TikTok OAuth: state mismatch.");
            if (!string.IsNullOrWhiteSpace(error)) throw new Exception($"TikTok OAuth error: {error}");
            if (string.IsNullOrWhiteSpace(code)) throw new Exception("TikTok OAuth: code fehlt.");

            onStatus?.Invoke("TikTok OAuth Code erhalten. Tausche gegen Token …");

            return await ExchangeCodeAsync(clientKey, clientSecret, redirectUri, code, verifier, onStatus, ct);
        }
    }

    public async Task<TikTokTokenBundle> RefreshAsync(
        string clientKey,
        string clientSecret,
        string refreshToken,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(clientKey)) throw new Exception("TikTok Client Key fehlt.");
        if (string.IsNullOrWhiteSpace(clientSecret)) throw new Exception("TikTok Client Secret fehlt.");
        if (string.IsNullOrWhiteSpace(refreshToken)) throw new Exception("TikTok Refresh Token fehlt. Bitte erneut einloggen.");

        onStatus?.Invoke("TikTok: Refresh Token …");

        using var http = new HttpClient();
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_key"] = clientKey.Trim(),
            ["client_secret"] = clientSecret.Trim(),
            ["grant_type"] = "refresh_token",
            ["refresh_token"] = refreshToken.Trim()
        });

        var res = await http.PostAsync(TokenEndpoint, form, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new Exception($"TikTok Token Refresh HTTP {(int)res.StatusCode}: {body}");

        return ParseTokenResponse(body);
    }

    private static string BuildAuthorizeUrl(string clientKey, string redirectUri, string[] scopes, string state, string challenge)
    {
        var sb = new StringBuilder();
        sb.Append(AuthorizeEndpoint);
        sb.Append("?client_key=").Append(Uri.EscapeDataString(clientKey.Trim()));
        sb.Append("&response_type=code");
        sb.Append("&scope=").Append(Uri.EscapeDataString(string.Join(",", scopes)));
        sb.Append("&redirect_uri=").Append(Uri.EscapeDataString(redirectUri));
        sb.Append("&state=").Append(Uri.EscapeDataString(state));
        sb.Append("&code_challenge=").Append(Uri.EscapeDataString(challenge));
        sb.Append("&code_challenge_method=S256");
        return sb.ToString();
    }

    private static async Task<TikTokTokenBundle> ExchangeCodeAsync(
        string clientKey,
        string clientSecret,
        string redirectUri,
        string code,
        string verifier,
        Action<string>? onStatus,
        CancellationToken ct)
    {
        using var http = new HttpClient();
        var form = new FormUrlEncodedContent(new Dictionary<string, string>
        {
            ["client_key"] = clientKey.Trim(),
            ["client_secret"] = clientSecret.Trim(),
            ["grant_type"] = "authorization_code",
            ["code"] = code.Trim(),
            ["redirect_uri"] = redirectUri,
            ["code_verifier"] = verifier
        });

        var res = await http.PostAsync(TokenEndpoint, form, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
            throw new Exception($"TikTok Token HTTP {(int)res.StatusCode}: {body}");

        var bundle = ParseTokenResponse(body);
        onStatus?.Invoke("TikTok Token erhalten.");
        return bundle;
    }

    private static TikTokTokenBundle ParseTokenResponse(string json)
    {
        using var doc = JsonDocument.Parse(json);

        JsonElement root = doc.RootElement;

        // TikTok typically returns: { "data": { ... }, "message": "ok" }
        if (root.TryGetProperty("data", out var data))
            root = data;

        string access = root.TryGetProperty("access_token", out var at) ? at.GetString() ?? "" : "";
        string refresh = root.TryGetProperty("refresh_token", out var rt) ? rt.GetString() ?? "" : "";
        int expiresIn = root.TryGetProperty("expires_in", out var ei) && ei.TryGetInt32(out var n) ? n : 0;

        int refreshExpiresIn = root.TryGetProperty("refresh_expires_in", out var rei) && rei.TryGetInt32(out var rn) ? rn : 0;

        string? openId = root.TryGetProperty("open_id", out var oid) ? oid.GetString() : null;
        string? scope = root.TryGetProperty("scope", out var sc) ? sc.GetString() : null;
        string? tokenType = root.TryGetProperty("token_type", out var tt) ? tt.GetString() : null;

        var now = DateTimeOffset.UtcNow;

        return new TikTokTokenBundle
        {
            AccessToken = access,
            RefreshToken = refresh,
            AccessTokenExpiresAtUtc = expiresIn > 0 ? now.AddSeconds(expiresIn) : now.AddMinutes(30),
            RefreshTokenExpiresAtUtc = refreshExpiresIn > 0 ? now.AddSeconds(refreshExpiresIn) : null,
            OpenId = openId,
            Scope = scope,
            TokenType = tokenType
        };
    }

    private static int GetFreePort()
    {
        var l = new System.Net.Sockets.TcpListener(IPAddress.Loopback, 0);
        l.Start();
        var port = ((IPEndPoint)l.LocalEndpoint).Port;
        l.Stop();
        return port;
    }

    private static string GenerateCodeVerifier()
    {
        var bytes = RandomNumberGenerator.GetBytes(32);
        return Base64UrlEncode(bytes);
    }

    private static string GenerateCodeChallenge(string verifier)
    {
        using var sha = SHA256.Create();
        var hash = sha.ComputeHash(Encoding.ASCII.GetBytes(verifier));
        return Base64UrlEncode(hash);
    }

    private static string Base64UrlEncode(byte[] bytes)
    {
        return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
    }
}
