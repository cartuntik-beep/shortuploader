using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public class UploaderOrchestrator
{
    private readonly Func<AppSettings> _settingsProvider;
    private readonly Action<string> _onStatus;
    private readonly Action<int, QueueItem> _onQueueUpdate;

    private CancellationTokenSource? _cts;

    public UploaderOrchestrator(Func<AppSettings> settingsProvider, Action<string> onStatus, Action<int, QueueItem> onQueueUpdate)
    {
        _settingsProvider = settingsProvider;
        _onStatus = onStatus;
        _onQueueUpdate = onQueueUpdate;
    }

    public void RequestStop()
    {
        _cts?.Cancel();
    }

    public async Task RunAsync(List<QueueItem> items)
    {
        _cts = new CancellationTokenSource();
        var ct = _cts.Token;

        var s = _settingsProvider();

        // Prepare folders
        var folder = s.VideoFolder ?? "";
        if (string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder))
            throw new Exception("Video-Ordner ist ungültig.");

        var uploadedDir = Path.Combine(folder, "uploaded");
        var failedDir = Path.Combine(folder, "failed");
        var logsDir = Path.Combine(folder, "logs");
        Directory.CreateDirectory(uploadedDir);
        Directory.CreateDirectory(failedDir);
        Directory.CreateDirectory(logsDir);

        var logger = new JsonlLogger(logsDir);

        // Scheduling wait (optional)
        if (s.SchedulingEnabled && !string.IsNullOrWhiteSpace(s.SchedulingStartAtLocal))
        {
            await WaitForScheduleAsync(s, _onStatus, ct);
        }

        YouTubeServiceWrapper? yt = null;
        TikTokServiceWrapper? tt = null;

        if (s.YouTubeEnabled)
        {
            yt = new YouTubeServiceWrapper(s.YouTubeClientSecretsFile, s.YouTubeTokenFile, _onStatus);
        }

        if (s.TikTokEnabled)
        {
                        var store = new TikTokTokenStore();
            var oauth = new TikTokOAuthClient();
            var mgr = new TikTokTokenManager(store, oauth);
            var token = await mgr.GetValidAccessTokenAsync(s, _onStatus, ct);
            tt = new TikTokServiceWrapper(token);
        }

        for (var i = 0; i < items.Count; i++)
        {
            ct.ThrowIfCancellationRequested();

            var item = items[i];
            item.Status = "RUNNING";
            item.YouTubeResult = "";
            item.TikTokResult = "";
            _onQueueUpdate(i, item);

            _onStatus($"Bearbeite: {item.FileName}");
            
var planned = ParsePublishAtLocal(item.PublishAtLocal);

if (planned.HasValue)
{
    logger.Log("planned_slot", new { file = item.FullPath, publishAtLocal = planned.Value.ToString("yyyy-MM-dd HH:mm") });
}
else if (_settingsProvider().PlanningEnabled)
{
    _onStatus("Warnung: Planung aktiv, aber kein Slot gesetzt. Bitte \"Plan berechnen\" drücken oder Startdatum/Uhrzeiten prüfen.");
    logger.Log("planned_slot_missing", new { file = item.FullPath });
}

var sNow = _settingsProvider();
            if (sNow.PlanningEnabled && sNow.UsePlatformScheduling && !planned.HasValue)
            {
                _onStatus("WARN: Plattform-Planung aktiv, aber kein Slot gesetzt. YouTube wird als PRIVATE hochgeladen (nicht veröffentlicht).");
                logger.Log("platform_schedule_missing_slot", new { file = item.FullPath });
            }

            if (sNow.PlanningEnabled && planned.HasValue && sNow.UsePlatformScheduling)
            {
                _onStatus($"Plattform-Planung: Upload jetzt; geplante Veröffentlichung: {planned.Value:yyyy-MM-dd HH:mm}");
            }

            if (sNow.PlanningEnabled && planned.HasValue && !sNow.UsePlatformScheduling)
            {
                await WaitUntilSlotAsync(planned.Value, _onStatus, ct);
            }

            logger.Log("file_begin", new { item.FullPath });

            var ytOk = yt is null;
            var ttOk = tt is null;
            string ytId = "";
            string ttId = "";

            
// YouTube
if (yt is not null)
{
    try
    {
        ytId = await RunWithRetriesAsync(s, "youtube", async () =>
        {
            var title = TextTemplate.Apply(s.YouTubeTitleTemplate, item.FullPath);
            var desc = TextTemplate.Apply(s.YouTubeDescriptionTemplate, item.FullPath);
            var publishAt = ParsePublishAtLocal(item.PublishAtLocal);
                        var forcePrivate = sNow.UsePlatformScheduling;
                        var id = await yt.UploadAsync(item.FullPath, title, desc, s.YouTubeTags, s.YouTubeCategoryId, s.YouTubePrivacyStatus, publishAt, forcePrivate, _onStatus, ct);
            return id;
        }, logger, ct);

        ytOk = !string.IsNullOrWhiteSpace(ytId);
        item.YouTubeResult = ytOk ? ytId : "FAIL";
    }
    catch (Exception ex)
    {
        ytOk = false;
        item.YouTubeResult = "FAIL";
        _onStatus("YouTube Fehler: " + ex.Message);
        logger.Log("youtube_error", new { file = item.FullPath, error = ex.ToString() });
    }

    _onQueueUpdate(i, item);
}
            
// TikTok
if (tt is not null)
{
    try
    {
        ttId = await RunWithRetriesAsync(s, "tiktok", async () =>
        {
            var caption = TextTemplate.Apply(s.TikTokCaptionTemplate, item.FullPath);
            var (publishId, uploadUrl) = await tt.InitAsync(
                item.FullPath, caption, s.TikTokPrivacyLevel,
                s.TikTokIsAigc, s.TikTokDisableComment, s.TikTokDisableDuet, s.TikTokDisableStitch,
                s.TikTokCoverTimestampMs, chunkSize: 10_000_000, ct: ct);

            if (string.IsNullOrWhiteSpace(uploadUrl))
                throw new Exception("TikTok init: upload_url fehlt.");

            _onStatus("TikTok: Upload PUT…");
            await tt.UploadPutAsync(uploadUrl!, item.FullPath, ct);

            _onStatus("TikTok: Warte auf Publish…");
            await tt.WaitUntilCompleteAsync(publishId, _onStatus, ct);

            return publishId;
        }, logger, ct);

        ttOk = !string.IsNullOrWhiteSpace(ttId);
        item.TikTokResult = ttOk ? ttId : "FAIL";
    }
    catch (Exception ex)
    {
        ttOk = false;
        item.TikTokResult = "FAIL";
        _onStatus("TikTok Fehler: " + ex.Message);
        logger.Log("tiktok_error", new { file = item.FullPath, error = ex.ToString() });
    }

    _onQueueUpdate(i, item);
}
            var succeeded = s.MoveWhen == "both_succeeded" ? (ytOk && ttOk) : (ytOk || ttOk);

            if (succeeded)
            {
                var dst = SafeMove.MoveTo(item.FullPath, uploadedDir);
                item.Status = "DONE";
                _onQueueUpdate(i, item);
                logger.Log("file_moved_uploaded", new { from = item.FullPath, to = dst, youtube = ytId, tiktok = ttId });
                _onStatus($"OK → uploaded/: {item.FileName}");
            }
            else
            {
                var dst = SafeMove.MoveTo(item.FullPath, failedDir);
                item.Status = "FAILED";
                _onQueueUpdate(i, item);
                logger.Log("file_moved_failed", new { from = item.FullPath, to = dst, youtube = ytId, tiktok = ttId });
                _onStatus($"FAIL → failed/: {item.FileName}");
            }

            logger.Log("file_end", new { item.FullPath });
        }

        _onStatus("Fertig.");
    }

    private async Task<string> RunWithRetriesAsync(AppSettings s, string platform, Func<Task<string>> fn, JsonlLogger logger, CancellationToken ct)
    {
        Exception? last = null;

        for (var attempt = 1; attempt <= s.RetryMaxAttempts; attempt++)
        {
            ct.ThrowIfCancellationRequested();
            try
            {
                _onStatus($"Versuch {attempt}/{s.RetryMaxAttempts} ({platform})…");
                logger.Log("attempt_start", new { platform, attempt });

                var res = await fn();

                logger.Log("attempt_success", new { platform, attempt });
                return res;
            }
            catch (Exception ex)
            {
                last = ex;
                logger.Log("attempt_error", new { platform, attempt, error = ex.Message });

                if (attempt == s.RetryMaxAttempts) break;

                var delay = Backoff.Compute(s.RetryBaseBackoffSeconds, s.RetryMaxBackoffSeconds, attempt);
                _onStatus($"Fehler: {ex.Message} — Retry in ~{(int)delay.TotalSeconds}s");
                await Task.Delay(delay, ct);
            }
        }

        throw new Exception($"Alle Versuche fehlgeschlagen ({platform}). Letzter Fehler: {last?.Message}");
    }


private static DateTime? ParsePublishAtLocal(string text)
{
    if (string.IsNullOrWhiteSpace(text)) return null;
    if (DateTime.TryParseExact(text.Trim(), "yyyy-MM-dd HH:mm", System.Globalization.CultureInfo.InvariantCulture,
        System.Globalization.DateTimeStyles.None, out var dt))
        return dt;
    return null;
}

private static async Task WaitUntilSlotAsync(DateTime slotLocal, Action<string> onStatus, CancellationToken ct)
{
    var now = DateTime.Now;
    if (slotLocal <= now) return;

    var wait = slotLocal - now;
    onStatus($"Warte bis geplant: {slotLocal:yyyy-MM-dd HH:mm}…");
    await Task.Delay(wait, ct);
}

    private static async Task WaitForScheduleAsync(AppSettings s, Action<string> onStatus, CancellationToken ct)
    {
        var start = DateTime.ParseExact(s.SchedulingStartAtLocal, "yyyy-MM-dd HH:mm", System.Globalization.CultureInfo.InvariantCulture);
        var interval = TimeSpan.FromMinutes(Math.Max(1, s.SchedulingIntervalMinutes));

        var now = DateTime.Now;

        DateTime next;
        if (now <= start) next = start;
        else
        {
            var delta = now - start;
            var slots = (int)(delta.TotalMinutes / interval.TotalMinutes) + 1;
            next = start.AddMinutes(slots * interval.TotalMinutes);
        }

        var wait = next - now;
        if (wait.TotalSeconds > 1)
        {
            onStatus($"Warte bis Slot: {next:yyyy-MM-dd HH:mm}…");
            await Task.Delay(wait, ct);
        }
    }
}
