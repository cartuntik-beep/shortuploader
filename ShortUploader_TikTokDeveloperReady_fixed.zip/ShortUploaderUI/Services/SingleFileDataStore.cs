using Google.Apis.Util.Store;
using System.Text;
using System.Text.Json;

namespace ShortUploaderUI.Services;

// Minimal IDataStore that writes the credential blob into a single JSON file path
public class SingleFileDataStore : IDataStore
{
    private readonly string _path;
    private readonly object _lock = new();

    public SingleFileDataStore(string path)
    {
        _path = path;
    }

    public Task ClearAsync()
    {
        lock (_lock)
        {
            if (File.Exists(_path)) File.Delete(_path);
        }
        return Task.CompletedTask;
    }

    public Task DeleteAsync<T>(string key)
    {
        // Single file: delete file
        return ClearAsync();
    }

    public Task<T> GetAsync<T>(string key)
    {
        lock (_lock)
        {
            if (!File.Exists(_path)) return Task.FromResult(default(T)!);
            var json = File.ReadAllText(_path, Encoding.UTF8);
            var obj = JsonSerializer.Deserialize<T>(json);
            return Task.FromResult(obj!);
        }
    }

    public Task StoreAsync<T>(string key, T value)
    {
        lock (_lock)
        {
            var json = JsonSerializer.Serialize(value, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_path, json, Encoding.UTF8);
        }
        return Task.CompletedTask;
    }
}
