using ShortUploaderUI.Models;

namespace ShortUploaderUI.Services;

public class TikTokTokenManager
{
    private readonly TikTokTokenStore _store;
    private readonly TikTokOAuthClient _oauth;

    public TikTokTokenManager(TikTokTokenStore store, TikTokOAuthClient oauth)
    {
        _store = store;
        _oauth = oauth;
    }

    public TikTokTokenBundle? Current => _store.Load();

    public void Logout() => _store.Clear();

    public async Task<string> GetValidAccessTokenAsync(AppSettings settings, Action<string>? onStatus, CancellationToken ct)
    {
        var bundle = _store.Load();
        if (bundle == null)
            throw new Exception("TikTok: Nicht eingeloggt. Bitte 'TikTok Login' ausführen.");

        if (bundle.IsAccessTokenValid())
            return bundle.AccessToken;

        if (!bundle.HasRefresh)
            throw new Exception("TikTok: Access Token abgelaufen und kein Refresh Token vorhanden. Bitte neu einloggen.");

        var refreshed = await _oauth.RefreshAsync(
            settings.TikTokClientKey,
            settings.TikTokClientSecret,
            bundle.RefreshToken,
            onStatus,
            ct);

        // Some responses may not include a refresh_token; keep old refresh token if missing
        if (string.IsNullOrWhiteSpace(refreshed.RefreshToken))
            refreshed.RefreshToken = bundle.RefreshToken;

        _store.Save(refreshed);
        return refreshed.AccessToken;
    }
}
