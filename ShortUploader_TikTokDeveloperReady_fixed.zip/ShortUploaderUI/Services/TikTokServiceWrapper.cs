using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;

namespace ShortUploaderUI.Services;

public class TikTokServiceWrapper
{
    private readonly HttpClient _http;
    private readonly string _accessToken;

    public TikTokServiceWrapper(string accessToken)
    {
        _accessToken = accessToken?.Trim() ?? "";
        if (string.IsNullOrWhiteSpace(_accessToken))
            throw new Exception("TikTok Access Token fehlt.");

        _http = new HttpClient
        {
            BaseAddress = new Uri("https://open.tiktokapis.com/")
        };
        _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _accessToken);
    }

    public async Task<(string publishId, string? uploadUrl)> InitAsync(string videoPath, string caption, string privacyLevel,
        bool isAigc, bool disableComment, bool disableDuet, bool disableStitch, int coverTimestampMs, int chunkSize, CancellationToken ct)
    {
        var size = new FileInfo(videoPath).Length;
        var totalChunks = (size + chunkSize - 1) / chunkSize;

        var payload = new
        {
            post_info = new
            {
                title = caption,
                privacy_level = privacyLevel,
                disable_comment = disableComment,
                disable_duet = disableDuet,
                disable_stitch = disableStitch,
                video_cover_timestamp_ms = coverTimestampMs,
                is_aigc = isAigc
            },
            source_info = new
            {
                source = "FILE_UPLOAD",
                video_size = size,
                chunk_size = chunkSize,
                total_chunk_count = totalChunks
            }
        };

        var json = JsonSerializer.Serialize(payload);
        var res = await _http.PostAsync("v2/post/publish/video/init/",
            new StringContent(json, Encoding.UTF8, "application/json"), ct);

        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new Exception($"TikTok init HTTP {(int)res.StatusCode}: {body}");

        using var doc = JsonDocument.Parse(body);
        var errorCode = doc.RootElement.GetProperty("error").GetProperty("code").GetString();
        if (!string.Equals(errorCode, "ok", StringComparison.OrdinalIgnoreCase))
            throw new Exception($"TikTok init error: {body}");

        var data = doc.RootElement.GetProperty("data");
        var publishId = data.GetProperty("publish_id").GetString() ?? "";
        var uploadUrl = data.TryGetProperty("upload_url", out var u) ? u.GetString() : null;

        return (publishId, uploadUrl);
    }

    public async Task UploadPutAsync(string uploadUrl, string videoPath, CancellationToken ct)
    {
        var bytes = await File.ReadAllBytesAsync(videoPath, ct);
        var size = bytes.Length;

        using var req = new HttpRequestMessage(HttpMethod.Put, uploadUrl);
        req.Content = new ByteArrayContent(bytes);
        req.Content.Headers.ContentType = new MediaTypeHeaderValue("video/mp4");
        req.Content.Headers.ContentLength = size;
        req.Headers.TryAddWithoutValidation("Content-Range", $"bytes 0-{size - 1}/{size}");

        using var client = new HttpClient();
        var res = await client.SendAsync(req, ct);
        if ((int)res.StatusCode is not (200 or 201 or 204))
        {
            var txt = await res.Content.ReadAsStringAsync(ct);
            throw new Exception($"TikTok PUT HTTP {(int)res.StatusCode}: {txt}");
        }
    }

    public async Task<(string status, string? failReason)> FetchStatusAsync(string publishId, CancellationToken ct)
    {
        var payload = JsonSerializer.Serialize(new { publish_id = publishId });
        var res = await _http.PostAsync("v2/post/publish/status/fetch/",
            new StringContent(payload, Encoding.UTF8, "application/json"), ct);

        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode) throw new Exception($"TikTok status HTTP {(int)res.StatusCode}: {body}");

        using var doc = JsonDocument.Parse(body);
        var errorCode = doc.RootElement.GetProperty("error").GetProperty("code").GetString();
        if (!string.Equals(errorCode, "ok", StringComparison.OrdinalIgnoreCase))
            throw new Exception($"TikTok status error: {body}");

        var data = doc.RootElement.GetProperty("data");
        var status = data.TryGetProperty("status", out var s) ? s.GetString() ?? "" : "";
        var fail = data.TryGetProperty("fail_reason", out var f) ? f.GetString() : null;
        return (status, fail);
    }

    public async Task WaitUntilCompleteAsync(string publishId, Action<string> onStatus, CancellationToken ct, int maxWaitSeconds = 300)
    {
        var start = DateTime.UtcNow;
        while (true)
        {
            ct.ThrowIfCancellationRequested();
            var (status, fail) = await FetchStatusAsync(publishId, ct);
            onStatus($"TikTok: Status {status}");

            if (status == "PUBLISH_COMPLETE") return;
            if (status == "FAILED") throw new Exception($"TikTok FAILED: {fail}");

            if ((DateTime.UtcNow - start).TotalSeconds > maxWaitSeconds)
                throw new Exception("TikTok Timeout beim Warten auf Status.");

            await Task.Delay(TimeSpan.FromSeconds(3), ct);
        }
    }
}
