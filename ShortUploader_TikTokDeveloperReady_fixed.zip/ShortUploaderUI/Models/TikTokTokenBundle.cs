namespace ShortUploaderUI.Models;

public class TikTokTokenBundle
{
    public string AccessToken { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public DateTimeOffset AccessTokenExpiresAtUtc { get; set; }
    public DateTimeOffset? RefreshTokenExpiresAtUtc { get; set; }

    public string? OpenId { get; set; }
    public string? Scope { get; set; }
    public string? TokenType { get; set; }

    public bool HasRefresh => !string.IsNullOrWhiteSpace(RefreshToken);

    public bool IsAccessTokenValid(TimeSpan? skew = null)
    {
        var s = skew ?? TimeSpan.FromSeconds(60);
        return !string.IsNullOrWhiteSpace(AccessToken) && AccessTokenExpiresAtUtc > DateTimeOffset.UtcNow.Add(s);
    }
}
