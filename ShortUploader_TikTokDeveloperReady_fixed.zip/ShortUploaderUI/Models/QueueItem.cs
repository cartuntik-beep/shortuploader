namespace ShortUploaderUI.Models;

public class QueueItem
{
    public string FullPath { get; set; } = "";
    public string FileName { get; set; } = "";
    public string Status { get; set; } = "READY";
    public string YouTubeResult { get; set; } = "";
    public string TikTokResult { get; set; } = "";
    public string PublishAtLocal { get; set; } = "";
}
