using System.Windows;

namespace ShortUploaderUI;

public partial class App : System.Windows.Application
{
}
